        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/plyr/3.7.2/plyr.min.js"></script>
    <script>
        // Mobile sidebar toggle
        document.querySelector('.menu-toggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(e) {
            const sidebar = document.querySelector('.sidebar');
            const menuToggle = document.querySelector('.menu-toggle');
            
            if (window.innerWidth <= 768 && 
                !sidebar.contains(e.target) && 
                !menuToggle.contains(e.target) && 
                sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        });

        // Initialize video players
        document.addEventListener('DOMContentLoaded', function() {
            const videoPlayers = document.querySelectorAll('.video-player');
            if (videoPlayers.length > 0) {
                videoPlayers.forEach(player => {
                    new Plyr(player, {
                        controls: ['play', 'progress', 'current-time', 'mute', 'volume', 'fullscreen'],
                        hideControls: true,
                        ratio: '16:9'
                    });
                });
            }
        });

        // Add animation classes on page load
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.animate-fade-in').forEach((el, i) => {
                setTimeout(() => {
                    el.classList.add('fade-in');
                }, i * 100);
            });

            document.querySelectorAll('.animate-slide-up').forEach((el, i) => {
                setTimeout(() => {
                    el.classList.add('slide-up');
                }, i * 100);
            });
        });

        // Check if fileInput is not already defined
        if (typeof fileInput === 'undefined') {
            const fileInput = document.querySelector('.file-input');
            if (fileInput) {
                fileInput.addEventListener('change', function() {
                    const file = this.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            const preview = document.querySelector('.file-preview');
                            if (preview) {
                                preview.innerHTML = `
                                    <video class="video-preview" controls>
                                        <source src="${e.target.result}" type="${file.type}">
                                    </video>
                                    <p class="file-name">${file.name}</p>
                                `;
                            }
                        };
                        reader.readAsDataURL(file);
                    }
                });
            }
        }

        // Form validation
        const seminarForm = document.querySelector('.seminar-form');
        if (seminarForm) {
            seminarForm.addEventListener('submit', function(e) {
                const title = document.querySelector('#title').value.trim();
                const description = document.querySelector('#description').value.trim();
                const video = document.querySelector('#video').files[0];

                if (!title || !description || !video) {
                    e.preventDefault();
                    alert('Please fill in all required fields and upload a video.');
                }
            });
        }
    </script>
</body>
</html> 