<?php
require_once 'includes/header.php';
require_once '../config/database.php';

$conn = getDBConnection();

// Get total seminars uploaded by the student
$stmt = $conn->prepare("SELECT COUNT(*) as total_seminars FROM seminars WHERE student_id = ?");
$stmt->bind_param("i", $user['user_id']);
$stmt->execute();
$total_seminars = $stmt->get_result()->fetch_assoc()['total_seminars'];

// Get evaluated seminars count
$stmt = $conn->prepare("SELECT COUNT(*) as evaluated_seminars FROM seminars WHERE student_id = ? AND evaluation_status = 'evaluated'");
$stmt->bind_param("i", $user['user_id']);
$stmt->execute();
$evaluated_seminars = $stmt->get_result()->fetch_assoc()['evaluated_seminars'];

// Get average score
$stmt = $conn->prepare("SELECT AVG(score) as avg_score FROM seminar_evaluations WHERE seminar_id IN (SELECT seminar_id FROM seminars WHERE student_id = ?)");
$stmt->bind_param("i", $user['user_id']);
$stmt->execute();
$avg_score = $stmt->get_result()->fetch_assoc()['avg_score'] ?? 0;

// Get recent seminars
$stmt = $conn->prepare("
    SELECT s.*, se.score, se.remarks 
    FROM seminars s 
    LEFT JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id 
    WHERE s.student_id = ? 
    ORDER BY s.created_at DESC 
    LIMIT 3
");
$stmt->bind_param("i", $user['user_id']);
$stmt->execute();
$recent_seminars = $stmt->get_result();
?>

<div class="dashboard-container">
    <!-- Welcome Section -->
    <div class="welcome-section animate-fade-in">
        <h1>Welcome back, <?php echo htmlspecialchars($user['full_name']); ?>!</h1>
        <p>Track your seminar progress and evaluations</p>
    </div>

    <!-- Statistics Grid -->
    <div class="stats-grid">
        <div class="stat-card animate-slide-up">
            <i class="fas fa-video"></i>
            <div class="stat-info">
                <h3>Total Seminars</h3>
                <p><?php echo $total_seminars; ?></p>
            </div>
        </div>
        <div class="stat-card animate-slide-up" style="animation-delay: 0.1s;">
            <i class="fas fa-check-circle"></i>
            <div class="stat-info">
                <h3>Evaluated Seminars</h3>
                <p><?php echo $evaluated_seminars; ?></p>
            </div>
        </div>
        <div class="stat-card animate-slide-up" style="animation-delay: 0.2s;">
            <i class="fas fa-star"></i>
            <div class="stat-info">
                <h3>Average Score</h3>
                <p><?php echo number_format($avg_score, 1); ?>/10</p>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions animate-fade-in" style="animation-delay: 0.3s;">
        <h2>Quick Actions</h2>
        <div class="action-buttons">
            <a href="upload_seminar.php" class="btn-primary">
                <i class="fas fa-upload"></i>
                Upload New Seminar
            </a>
            <a href="my_seminars.php" class="btn-secondary">
                <i class="fas fa-video"></i>
                View My Seminars
            </a>
        </div>
    </div>

    <!-- Recent Seminars -->
    <div class="recent-seminars animate-fade-in" style="animation-delay: 0.4s;">
        <div class="section-header">
            <h2>Recent Seminars</h2>
            <a href="my_seminars.php" class="view-all">View All</a>
        </div>
        <div class="seminars-grid">
            <?php while ($seminar = $recent_seminars->fetch_assoc()): ?>
                <div class="seminar-card">
                    <div class="video-thumbnail">
                        <video class="video-player" poster="../uploads/thumbnails/<?php echo $seminar['thumbnail_url']; ?>">
                            <source src="../uploads/videos/<?php echo $seminar['video_url']; ?>" type="video/mp4">
                        </video>
                        <span class="status-badge <?php echo $seminar['evaluation_status']; ?>">
                            <?php echo ucfirst($seminar['evaluation_status']); ?>
                        </span>
                    </div>
                    <div class="seminar-info">
                        <h3><?php echo htmlspecialchars($seminar['title']); ?></h3>
                        <p class="date">
                            <i class="fas fa-calendar"></i>
                            <?php echo date('M d, Y', strtotime($seminar['created_at'])); ?>
                        </p>
                        <?php if ($seminar['evaluation_status'] === 'evaluated'): ?>
                            <div class="evaluation-info">
                                <div class="score">
                                    <i class="fas fa-star"></i>
                                    Score: <?php echo $seminar['score']; ?>/10
                                </div>
                                <?php if ($seminar['remarks']): ?>
                                    <p class="remarks"><?php echo htmlspecialchars($seminar['remarks']); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<style>
    .dashboard-container {
        max-width: 1200px;
        margin: 0 auto;
    }

    .welcome-section {
        margin-bottom: 2rem;
    }

    .welcome-section h1 {
        color: var(--text-color);
        margin-bottom: 0.5rem;
    }

    .welcome-section p {
        color: #666;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .stat-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        gap: 1rem;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }

    .stat-card i {
        font-size: 2rem;
        color: var(--primary-color);
        background: var(--light-bg);
        padding: 1rem;
        border-radius: 50%;
    }

    .stat-info h3 {
        font-size: 0.9rem;
        color: #666;
        margin-bottom: 0.5rem;
    }

    .stat-info p {
        font-size: 1.5rem;
        font-weight: 600;
        color: var(--text-color);
    }

    .quick-actions {
        margin-bottom: 2rem;
    }

    .quick-actions h2 {
        margin-bottom: 1rem;
        color: var(--text-color);
    }

    .action-buttons {
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
    }

    .seminars-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1.5rem;
        margin-top: 1rem;
    }

    .seminar-card {
        background: white;
        border-radius: 10px;
        overflow: hidden;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .seminar-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }

    .video-thumbnail {
        position: relative;
        padding-top: 56.25%; /* 16:9 Aspect Ratio */
    }

    .video-player {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .status-badge {
        position: absolute;
        top: 1rem;
        right: 1rem;
        padding: 0.25rem 0.75rem;
        border-radius: 15px;
        font-size: 0.85rem;
        font-weight: 500;
        z-index: 1;
    }

    .status-badge.pending {
        background: #fff3cd;
        color: #856404;
    }

    .status-badge.evaluated {
        background: #d4edda;
        color: #155724;
    }

    .seminar-info {
        padding: 1rem;
    }

    .seminar-info h3 {
        margin-bottom: 0.5rem;
        color: var(--text-color);
    }

    .date {
        color: #666;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 0.5rem;
    }

    .evaluation-info {
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid var(--border-color);
    }

    .score {
        color: var(--primary-color);
        font-weight: 500;
        margin-bottom: 0.5rem;
    }

    .remarks {
        font-size: 0.9rem;
        color: #666;
        line-height: 1.4;
    }

    @media (max-width: 768px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }

        .action-buttons {
            flex-direction: column;
        }

        .action-buttons a {
            width: 100%;
        }

        .seminars-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php
require_once 'includes/footer.php';
$conn->close();
?> 