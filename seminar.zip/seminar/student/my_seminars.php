<?php
require_once 'includes/header.php';
require_once '../config/database.php';

$conn = getDBConnection();

// Get all seminars for the current student
$stmt = $conn->prepare("
    SELECT 
        s.seminar_id,
        s.title,
        s.description,
        s.video_url,
        s.thumbnail_url,
        s.created_at,
        s.evaluation_status,
        se.score,
        se.remarks,
        f.full_name as evaluator_name
    FROM seminars s
    LEFT JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id
    LEFT JOIN users f ON se.faculty_id = f.user_id
    WHERE s.student_id = ?
    ORDER BY s.created_at DESC
");

$stmt->bind_param("i", $user['user_id']);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="seminars-container">
    <div class="page-header">
        <h2><i class="fas fa-video"></i> My Seminars</h2>
        <a href="upload_seminar.php" class="btn-primary">
            <i class="fas fa-plus"></i> Upload New Seminar
        </a>
    </div>

    <?php if ($result->num_rows === 0): ?>
    <div class="empty-state">
        <i class="fas fa-video-slash"></i>
        <h3>No Seminars Yet</h3>
        <p>You haven't uploaded any seminars yet. Click the button above to upload your first seminar.</p>
    </div>
    <?php else: ?>
    <div class="seminars-grid">
        <?php while ($seminar = $result->fetch_assoc()): ?>
        <div class="seminar-card">
            <a href="<?php echo htmlspecialchars($seminar['video_url']); ?>" target="_blank" class="video-container">
                <img src="../uploads/thumbnails/<?php echo htmlspecialchars($seminar['thumbnail_url']); ?>" 
                     alt="<?php echo htmlspecialchars($seminar['title']); ?> thumbnail"
                     class="seminar-thumbnail">
                <div class="play-overlay">
                    <i class="fas fa-play-circle"></i>
                </div>
            </a>
            <div class="seminar-info">
                <h3><?php echo htmlspecialchars($seminar['title']); ?></h3>
                <p class="description"><?php echo htmlspecialchars($seminar['description']); ?></p>
                <div class="meta-info">
                    <span class="date">
                        <i class="fas fa-calendar"></i>
                        <?php echo date('M d, Y', strtotime($seminar['created_at'])); ?>
                    </span>
                    <span class="status <?php echo strtolower($seminar['evaluation_status']); ?>">
                        <i class="fas fa-<?php echo $seminar['evaluation_status'] === 'evaluated' ? 'check-circle' : 'clock'; ?>"></i>
                        <?php echo ucfirst($seminar['evaluation_status']); ?>
                    </span>
                </div>
                <?php if ($seminar['evaluation_status'] === 'evaluated'): ?>
                <div class="evaluation-details">
                    <div class="score">
                        <span class="label">Score:</span>
                        <span class="value"><?php echo number_format($seminar['score'], 1); ?>/10</span>
                    </div>
                    <div class="evaluator">
                        <span class="label">Evaluated by:</span>
                        <span class="value"><?php echo htmlspecialchars($seminar['evaluator_name']); ?></span>
                    </div>
                    <?php if ($seminar['remarks']): ?>
                    <div class="remarks">
                        <span class="label">Remarks:</span>
                        <p><?php echo nl2br(htmlspecialchars($seminar['remarks'])); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>
</div>

<style>
    .seminars-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem;
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
    }

    .page-header h2 {
        color: var(--text-color);
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .empty-state {
        text-align: center;
        padding: 3rem;
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .empty-state i {
        font-size: 3rem;
        color: var(--primary-color);
        margin-bottom: 1rem;
    }

    .empty-state h3 {
        margin-bottom: 0.5rem;
        color: var(--text-color);
    }

    .empty-state p {
        color: #666;
    }

    .seminars-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 2rem;
    }

    .seminar-card {
        background: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        transition: transform 0.3s;
    }

    .seminar-card:hover {
        transform: translateY(-5px);
    }

    .video-container {
        position: relative;
        padding-top: 56.25%; /* 16:9 Aspect Ratio */
        display: block;
        overflow: hidden;
        background: #000;
    }

    .seminar-thumbnail {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .play-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(0, 0, 0, 0.4);
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .play-overlay i {
        font-size: 4rem;
        color: white;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    }

    .video-container:hover .seminar-thumbnail {
        transform: scale(1.05);
    }

    .video-container:hover .play-overlay {
        opacity: 1;
    }

    .seminar-info {
        padding: 1.5rem;
    }

    .seminar-info h3 {
        margin-bottom: 0.5rem;
        color: var(--text-color);
    }

    .description {
        color: #666;
        margin-bottom: 1rem;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .meta-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
        font-size: 0.9rem;
    }

    .date {
        color: #666;
    }

    .status {
        padding: 0.25rem 0.5rem;
        border-radius: 15px;
        display: flex;
        align-items: center;
        gap: 0.25rem;
        font-size: 0.85rem;
    }

    .status.pending {
        background: #fff3cd;
        color: #856404;
    }

    .status.evaluated {
        background: #d4edda;
        color: #155724;
    }

    .evaluation-details {
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid var(--border-color);
    }

    .evaluation-details > div {
        margin-bottom: 0.5rem;
    }

    .evaluation-details .label {
        color: #666;
        font-size: 0.9rem;
        margin-right: 0.5rem;
    }

    .evaluation-details .value {
        color: var(--text-color);
        font-weight: 500;
    }

    .evaluation-details .score .value {
        color: var(--primary-color);
    }

    .remarks p {
        margin-top: 0.25rem;
        font-size: 0.9rem;
        color: #666;
        line-height: 1.5;
    }

    @media (max-width: 768px) {
        .seminars-container {
            padding: 1rem;
        }

        .page-header {
            flex-direction: column;
            gap: 1rem;
            text-align: center;
        }

        .seminars-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php
$stmt->close();
$conn->close();
require_once 'includes/footer.php';
?> 