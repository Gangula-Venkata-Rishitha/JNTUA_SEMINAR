<?php
require_once 'includes/header.php';
require_once '../config/database.php';

$conn = getDBConnection();
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $video_url = trim($_POST['video_url']);

    // Validate input
    $errors = [];
    if (empty($title)) $errors[] = "Title is required";
    if (empty($description)) $errors[] = "Description is required";
    if (empty($video_url)) $errors[] = "Video URL is required";
    if (!filter_var($video_url, FILTER_VALIDATE_URL)) $errors[] = "Please enter a valid URL";

    // Validate and process thumbnail
    $thumbnail_filename = '';
    if (!isset($_FILES['thumbnail']) || $_FILES['thumbnail']['error'] !== UPLOAD_ERR_OK) {
        $errors[] = "Please select a thumbnail image";
    } else {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 5 * 1024 * 1024; // 5MB limit

        if (!in_array($_FILES['thumbnail']['type'], $allowed_types)) {
            $errors[] = "Invalid image format. Allowed formats: JPG, PNG, GIF";
        }

        if ($_FILES['thumbnail']['size'] > $max_size) {
            $errors[] = "Thumbnail size exceeds limit. Maximum size allowed is 5MB";
        }
    }

    if (empty($errors)) {
        // Create upload directories if they don't exist
        $thumbnail_dir = "../uploads/thumbnails/";
        $videos_dir = "../uploads/videos/";
        if (!file_exists($thumbnail_dir)) mkdir($thumbnail_dir, 0777, true);
        if (!file_exists($videos_dir)) mkdir($videos_dir, 0777, true);

        // Generate unique filename for thumbnail
        $thumbnail_filename = uniqid() . '_' . basename($_FILES['thumbnail']['name']);
        $thumbnail_path = $thumbnail_dir . $thumbnail_filename;

        if (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $thumbnail_path)) {
            // Insert seminar record
            $stmt = $conn->prepare("
                INSERT INTO seminars (student_id, title, description, video_url, thumbnail_url, evaluation_status)
                VALUES (?, ?, ?, ?, ?, 'pending')
            ");
            $stmt->bind_param("issss", $user['user_id'], $title, $description, $video_url, $thumbnail_filename);

            if ($stmt->execute()) {
                $success_message = "Seminar uploaded successfully!";
                // Clear form data
                $_POST = array();
            } else {
                $error_message = "Error uploading seminar: " . $conn->error;
                // Remove uploaded thumbnail if database insert fails
                unlink($thumbnail_path);
            }
        } else {
            $error_message = "Error uploading thumbnail image";
        }
    } else {
        $error_message = implode("<br>", $errors);
    }
}
?>

<div class="upload-container">
    <div class="form-header animate-fade-in">
        <h2><i class="fas fa-upload"></i> Upload New Seminar</h2>
        <p>Share your recorded seminar with your faculty</p>
    </div>

    <?php if ($success_message): ?>
        <div class="alert success animate-slide-up">
            <i class="fas fa-check-circle"></i>
            <?php echo $success_message; ?>
        </div>
    <?php endif; ?>

    <?php if ($error_message): ?>
        <div class="alert error animate-slide-up">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo $error_message; ?>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="upload-form animate-slide-up">
        <div class="form-grid">
            <div class="form-group">
                <label for="title">Seminar Title</label>
                <input type="text" id="title" name="title" 
                       value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>"
                       placeholder="Enter seminar title">
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="4" 
                          placeholder="Enter seminar description"><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
            </div>

            <div class="form-group">
                <label for="video_url">Video URL</label>
                <input type="url" id="video_url" name="video_url" 
                       value="<?php echo isset($_POST['video_url']) ? htmlspecialchars($_POST['video_url']) : ''; ?>"
                       placeholder="Enter video URL (YouTube, Vimeo, etc.)">
                <small class="help-text">Paste the URL of your video from YouTube, Vimeo, or other video platforms</small>
            </div>

            <div class="form-group upload-group">
                <label for="thumbnail">Upload Thumbnail</label>
                <div class="upload-area" id="uploadArea">
                    <input type="file" id="thumbnail" name="thumbnail" class="file-input" 
                           accept="image/jpeg,image/png,image/gif">
                    <div class="upload-content">
                        <i class="fas fa-image"></i>
                        <p>Drag & drop your thumbnail here or click to browse</p>
                        <span>Supported formats: JPG, PNG, GIF (Max size: 5MB)</span>
                    </div>
                </div>
                <div class="thumbnail-preview"></div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn-primary">
                <i class="fas fa-upload"></i>
                Upload Seminar
            </button>
            <button type="reset" class="btn-secondary">
                <i class="fas fa-undo"></i>
                Reset Form
            </button>
        </div>
    </form>
</div>

<style>
    .upload-container {
        max-width: 800px;
        margin: 0 auto;
        background: white;
        padding: 2rem;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .form-header {
        text-align: center;
        margin-bottom: 2rem;
    }

    .form-header h2 {
        color: var(--text-color);
        margin-bottom: 0.5rem;
    }

    .form-header p {
        color: #666;
    }

    .alert {
        padding: 1rem;
        border-radius: 5px;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .alert.success {
        background: #d4edda;
        color: #155724;
    }

    .alert.error {
        background: #f8d7da;
        color: #721c24;
    }

    .form-grid {
        display: grid;
        gap: 1.5rem;
        margin-bottom: 1.5rem;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .form-group label {
        font-weight: 500;
        color: var(--text-color);
    }

    .form-group input,
    .form-group textarea {
        padding: 0.75rem;
        border: 1px solid var(--border-color);
        border-radius: 5px;
        font-size: 0.9rem;
        transition: border-color 0.3s;
    }

    .form-group input:focus,
    .form-group textarea:focus {
        outline: none;
        border-color: var(--primary-color);
    }

    .upload-area {
        position: relative;
        border: 2px dashed var(--border-color);
        border-radius: 10px;
        padding: 2rem;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s;
    }

    .upload-area:hover {
        border-color: var(--primary-color);
        background: var(--light-bg);
    }

    .upload-area.dragover {
        border-color: var(--primary-color);
        background: var(--light-bg);
    }

    .file-input {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        cursor: pointer;
    }

    .upload-content {
        pointer-events: none;
    }

    .upload-content i {
        font-size: 3rem;
        color: var(--primary-color);
        margin-bottom: 1rem;
    }

    .upload-content p {
        margin-bottom: 0.5rem;
        color: var(--text-color);
    }

    .upload-content span {
        font-size: 0.85rem;
        color: #666;
    }

    .file-preview {
        margin-top: 1rem;
    }

    .video-preview {
        width: 100%;
        border-radius: 5px;
        margin-bottom: 0.5rem;
    }

    .file-name {
        font-size: 0.9rem;
        color: #666;
    }

    .form-actions {
        display: flex;
        gap: 1rem;
        justify-content: flex-end;
    }

    @media (max-width: 768px) {
        .form-actions {
            flex-direction: column;
        }

        .form-actions button {
            width: 100%;
        }
    }

    .upload-progress {
        margin-top: 1rem;
    }

    .progress-bar {
        width: 100%;
        height: 8px;
        background: var(--light-bg);
        border-radius: 4px;
        overflow: hidden;
    }

    .progress-fill {
        height: 100%;
        background: var(--primary-color);
        width: 0;
        transition: width 0.3s ease;
    }

    .progress-text {
        display: block;
        text-align: center;
        margin-top: 0.5rem;
        font-size: 0.9rem;
        color: var(--text-color);
    }

    .help-text {
        font-size: 0.85rem;
        color: #666;
        margin-top: 0.25rem;
    }

    .thumbnail-preview {
        margin-top: 1rem;
        text-align: center;
    }

    .thumbnail-preview img {
        max-width: 300px;
        max-height: 200px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .thumbnail-preview .file-name {
        margin-top: 0.5rem;
        font-size: 0.9rem;
        color: #666;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.querySelector('.file-input');

        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, preventDefaults, false);
        });

        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }

        ['dragenter', 'dragover'].forEach(eventName => {
            uploadArea.addEventListener(eventName, highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, unhighlight, false);
        });

        function highlight(e) {
            uploadArea.classList.add('dragover');
        }

        function unhighlight(e) {
            uploadArea.classList.remove('dragover');
        }

        uploadArea.addEventListener('drop', handleDrop, false);

        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            fileInput.files = files;
            handleFiles(files);
        }

        fileInput.addEventListener('change', function() {
            handleFiles(this.files);
        });

        function handleFiles(files) {
            if (files.length > 0) {
                const file = files[0];
                const maxSize = 5 * 1024 * 1024; // 5MB

                if (file.size > maxSize) {
                    alert('File size exceeds limit. Maximum size allowed is 5MB');
                    return;
                }

                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const preview = document.querySelector('.thumbnail-preview');
                        preview.innerHTML = `
                            <img src="${e.target.result}" alt="Thumbnail preview">
                            <p class="file-name">${file.name} (${formatFileSize(file.size)})</p>
                        `;
                    };
                    reader.readAsDataURL(file);
                }
            }
        }

        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
    });
</script>

<?php
require_once 'includes/footer.php';
$conn->close();
?> 
?> 