<?php
require_once 'includes/header.php';
require_once '../config/database.php';

$conn = getDBConnection();

// Get all seminars with their evaluation details for the current student
$stmt = $conn->prepare("
    SELECT 
        s.seminar_id,
        s.title,
        s.description,
        s.video_url,
        s.thumbnail_url,
        s.created_at,
        s.evaluation_status,
        se.score,
        se.remarks,
        se.evaluation_date,
        f.full_name as evaluator_name
    FROM seminars s
    LEFT JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id
    LEFT JOIN users f ON se.faculty_id = f.user_id
    WHERE s.student_id = ?
    ORDER BY s.created_at DESC
");

$stmt->bind_param("i", $user['user_id']);
$stmt->execute();
$seminars = $stmt->get_result();

// Get statistics
$stats_stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_seminars,
        COUNT(CASE WHEN evaluation_status = 'evaluated' THEN 1 END) as evaluated_count,
        COUNT(CASE WHEN evaluation_status = 'pending' THEN 1 END) as pending_count,
        ROUND(AVG(CASE WHEN evaluation_status = 'evaluated' THEN 
            (SELECT score FROM seminar_evaluations WHERE seminar_id = seminars.seminar_id)
        END), 1) as avg_score
    FROM seminars
    WHERE student_id = ?
");

$stats_stmt->bind_param("i", $user['user_id']);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();
?>

<div class="evaluations-container">
    <div class="page-header">
        <h2><i class="fas fa-star"></i> My Evaluations</h2>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-video"></i>
            </div>
            <div class="stat-info">
                <h3>Total Seminars</h3>
                <p class="stat-value"><?php echo $stats['total_seminars']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-info">
                <h3>Evaluated</h3>
                <p class="stat-value"><?php echo $stats['evaluated_count']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-info">
                <h3>Pending</h3>
                <p class="stat-value"><?php echo $stats['pending_count']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-star"></i>
            </div>
            <div class="stat-info">
                <h3>Average Score</h3>
                <p class="stat-value"><?php echo $stats['avg_score'] ?? 'N/A'; ?></p>
            </div>
        </div>
    </div>

    <!-- Seminars List -->
    <?php if ($seminars->num_rows === 0): ?>
    <div class="empty-state">
        <i class="fas fa-video"></i>
        <h3>No Seminars Found</h3>
        <p>You haven't uploaded any seminars yet.</p>
        <a href="upload_seminar.php" class="btn-primary">Upload Your First Seminar</a>
    </div>
    <?php else: ?>
    <div class="seminars-grid">
        <?php while ($seminar = $seminars->fetch_assoc()): ?>
        <div class="seminar-card <?php echo $seminar['evaluation_status']; ?>">
            <a href="<?php echo htmlspecialchars($seminar['video_url']); ?>" target="_blank" class="video-container">
                <img src="../uploads/thumbnails/<?php echo htmlspecialchars($seminar['thumbnail_url']); ?>" 
                     alt="<?php echo htmlspecialchars($seminar['title']); ?> thumbnail"
                     class="seminar-thumbnail">
                <div class="play-overlay">
                    <i class="fas fa-play-circle"></i>
                </div>
            </a>
            <div class="seminar-info">
                <div class="status-badge <?php echo $seminar['evaluation_status']; ?>">
                    <i class="fas fa-<?php echo $seminar['evaluation_status'] === 'evaluated' ? 'check-circle' : 'clock'; ?>"></i>
                    <?php echo ucfirst($seminar['evaluation_status']); ?>
                </div>
                <h3><?php echo htmlspecialchars($seminar['title']); ?></h3>
                <p class="description"><?php echo htmlspecialchars($seminar['description']); ?></p>
                <div class="meta-info">
                    <span class="date">
                        <i class="fas fa-calendar"></i>
                        Uploaded: <?php echo date('M d, Y', strtotime($seminar['created_at'])); ?>
                    </span>
                </div>
                
                <?php if ($seminar['evaluation_status'] === 'evaluated'): ?>
                <div class="evaluation-details">
                    <div class="score">
                        <span class="label">Score:</span>
                        <span class="value"><?php echo number_format($seminar['score'], 1); ?>/10</span>
                    </div>
                    <div class="evaluator">
                        <span class="label">Evaluated by:</span>
                        <span class="value"><?php echo htmlspecialchars($seminar['evaluator_name']); ?></span>
                    </div>
                    <div class="evaluation-date">
                        <span class="label">Evaluated on:</span>
                        <span class="value"><?php echo date('M d, Y', strtotime($seminar['evaluation_date'])); ?></span>
                    </div>
                    <?php if ($seminar['remarks']): ?>
                    <div class="remarks">
                        <span class="label">Remarks:</span>
                        <p><?php echo nl2br(htmlspecialchars($seminar['remarks'])); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <div class="pending-message">
                    <i class="fas fa-info-circle"></i>
                    Waiting for faculty evaluation
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>
</div>

<style>
.evaluations-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: white;
    border-radius: 10px;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.stat-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-color);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stat-icon i {
    font-size: 1.5rem;
    color: white;
}

.stat-info h3 {
    font-size: 0.9rem;
    color: #666;
    margin-bottom: 0.25rem;
}

.stat-value {
    font-size: 1.5rem;
    font-weight: 600;
    color: var(--text-color);
    margin: 0;
}

.seminars-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 1.5rem;
}

.seminar-card {
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: transform 0.3s;
}

.seminar-card:hover {
    transform: translateY(-5px);
}

.seminar-card.evaluated {
    border-left: 4px solid var(--primary-color);
}

.seminar-card.pending {
    border-left: 4px solid #ffc107;
}

.video-container {
    position: relative;
    display: block;
    padding-top: 56.25%;
    background: #f5f5f5;
}

.seminar-thumbnail {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.play-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s;
}

.play-overlay i {
    font-size: 3rem;
    color: white;
}

.video-container:hover .play-overlay {
    opacity: 1;
}

.seminar-info {
    padding: 1.5rem;
}

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.25rem 0.75rem;
    border-radius: 15px;
    font-size: 0.85rem;
    margin-bottom: 1rem;
}

.status-badge.evaluated {
    background: #e8f5e9;
    color: #2e7d32;
}

.status-badge.pending {
    background: #fff3e0;
    color: #f57c00;
}

.status-badge i {
    font-size: 0.9rem;
}

.seminar-info h3 {
    margin: 0 0 0.5rem 0;
    color: var(--text-color);
}

.description {
    color: #666;
    font-size: 0.9rem;
    margin-bottom: 1rem;
}

.meta-info {
    display: flex;
    gap: 1rem;
    color: #666;
    font-size: 0.85rem;
    margin-bottom: 1rem;
}

.meta-info i {
    margin-right: 0.25rem;
}

.evaluation-details {
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 1px solid var(--border-color);
}

.evaluation-details > div {
    margin-bottom: 0.75rem;
}

.evaluation-details .label {
    color: #666;
    font-size: 0.9rem;
    margin-right: 0.5rem;
}

.evaluation-details .value {
    color: var(--text-color);
    font-weight: 500;
}

.evaluation-details .score .value {
    color: var(--primary-color);
    font-size: 1.1rem;
}

.remarks p {
    margin: 0.5rem 0 0 0;
    font-size: 0.9rem;
    color: #666;
    line-height: 1.5;
}

.pending-message {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: #f57c00;
    font-size: 0.9rem;
    margin-top: 1rem;
    padding: 0.75rem;
    background: #fff3e0;
    border-radius: 5px;
}

.empty-state {
    text-align: center;
    padding: 3rem;
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.empty-state i {
    font-size: 3rem;
    color: #ccc;
    margin-bottom: 1rem;
}

.empty-state h3 {
    margin: 0 0 0.5rem 0;
    color: var(--text-color);
}

.empty-state p {
    color: #666;
    margin-bottom: 1.5rem;
}

@media (max-width: 768px) {
    .evaluations-container {
        padding: 1rem;
    }

    .stats-grid {
        grid-template-columns: 1fr 1fr;
    }

    .seminars-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<?php
$stmt->close();
$stats_stmt->close();
$conn->close();
require_once 'includes/footer.php';
?> 