# Project Information
This project is designed to manage HOD accounts for various departments in a university. It allows for easy creation and management of accounts for Heads of Departments.

# Installation Steps

## Prerequisites
- PHP 7.4 or higher
- MySQL Server installed on your system
- MySQL credentials (username and password)
- Composer (Download from https://getcomposer.org/download/)
- XAMPP/WAMP/MAMP (Any PHP development environment)

## Easy Installation
1. Download all the files to your computer
2. Place the project folder in your web server directory:
   - For XAMPP: `C:\xampp\htdocs\seminar`
   - For WAMP: `C:\wamp\www\seminar`
   - For MAMP: `/Applications/MAMP/htdocs/seminar`

3. For Windows Users:
   - Double click on `install_database.bat`
   - The script will:
     - Install PHP dependencies using Composer
     - Set up the database
   - Enter your MySQL username and password when prompted
   
4. For Linux/Mac Users:
   - Open terminal in the project directory
   - Make the script executable: `chmod +x install_database.sh`
   - Run the script: `./install_database.sh`
   - Enter your MySQL username and password when prompted

## Manual Installation Steps
If you prefer to install manually:

1. Open command prompt/terminal in the project directory
2. Run: `composer install`
3. Open your MySQL client
4. Log in to MySQL
5. Run: `source path/to/database.sql`

## Troubleshooting

### TCPDF or Other Class Not Found Errors
If you see class not found errors:

1. Delete these folders/files:
   ```
   vendor/
   composer.lock
   ```

2. Run these commands:
   ```bash
   composer clear-cache
   composer install --prefer-dist --no-cache
   ```

3. If you still have issues, try:
   ```bash
   composer install --prefer-dist --no-cache --ignore-platform-reqs
   ```

4. Make sure your PHP file includes the autoloader:
   ```php
   require_once __DIR__ . '/../vendor/autoload.php';
   ```

### GD Extension Error
If you see an error about the GD extension:

1. Locate your php.ini file:
   - For XAMPP: `C:\xampp\php\php.ini`
   - For WAMP: `C:\wamp\bin\php\php8.2.x\php.ini`
   - For MAMP: `/Applications/MAMP/bin/php/php8.2.x/conf/php.ini`

2. Open php.ini in a text editor
3. Find the line `;extension=gd`
4. Remove the semicolon (;) at the start of the line
5. Save the file
6. Restart your web server (Apache)

### Composer Install Errors
If composer install fails:

1. Try running with platform requirements ignored:
   ```bash
   composer install --ignore-platform-reqs
   ```

2. If that doesn't work, clear composer cache:
   ```bash
   composer clear-cache
   composer install --ignore-platform-reqs
   ```

3. If still having issues, try:
   ```bash
   composer update --ignore-platform-reqs
   ```

## Default Login Credentials

### HOD Account
- Username: hod
- Password: hod
- Department: Computer Science

### Faculty Account
- Username: faculty
- Password: faculty
- Department: Computer Science

### Student Account
- Username: 22001a0509
- Password: 22001a0509
- Department: Computer Science

# Manual Installation Steps
If you prefer to install manually:

1. Open your MySQL client
2. Log in to MySQL
3. Run the following command:
   ```sql
   source path/to/database.sql
   ```

Successfully created HOD account for CSE
Username: hod_cse
Password: CSE@2024
Department: CSE

Successfully created HOD account for ECE
Username: hod_ece
Password: ECE@2024
Department: ECE

Successfully created HOD account for EEE
Username: hod_eee
Password: EEE@2024
Department: EEE

Successfully created HOD account for MECH
Username: hod_mech
Password: MECH@2024
Department: MECH

Successfully created HOD account for CIVIL
Username: hod_civil
Password: CIVIL@2024
Department: CIVIL

Successfully created HOD account for CHEMICAL
Username: hod_chemical
Password: CHEMICAL@2024
Department: CHEMICAL
