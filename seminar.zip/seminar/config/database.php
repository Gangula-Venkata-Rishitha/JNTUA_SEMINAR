<?php
function getDBConnection() {
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'seminar_db';

    try {
        $conn = new mysqli($host, $username, $password, $database);
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }

        // Set charset to utf8mb4
        $conn->set_charset("utf8mb4");
        
        return $conn;
    } catch (Exception $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

// Create the database if it doesn't exist
function createDatabase() {
    $host = 'localhost';
    $username = 'root';
    $password = '';
    
    try {
        $conn = new mysqli($host, $username, $password);
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }
        
        // Create database if it doesn't exist
        $sql = "CREATE DATABASE IF NOT EXISTS seminar_db";
        if ($conn->query($sql) === FALSE) {
            throw new Exception("Error creating database: " . $conn->error);
        }
        
        // Select the database
        $conn->select_db("seminar_db");
        
        // Create users table if it doesn't exist
        $sql = "CREATE TABLE IF NOT EXISTS users (
            user_id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            department VARCHAR(50),
            role ENUM('student', 'faculty', 'hod') NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        
        if ($conn->query($sql) === FALSE) {
            throw new Exception("Error creating users table: " . $conn->error);
        }
        
        // Create seminars table if it doesn't exist
        $sql = "CREATE TABLE IF NOT EXISTS seminars (
            seminar_id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            video_url VARCHAR(255) NOT NULL,
            thumbnail_url VARCHAR(255),
            evaluation_status ENUM('pending', 'evaluated') DEFAULT 'pending',
            evaluation_remarks TEXT,
            evaluated_by INT,
            score DECIMAL(4,2),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,
            FOREIGN KEY (evaluated_by) REFERENCES users(user_id) ON DELETE SET NULL
        )";
        
        if ($conn->query($sql) === FALSE) {
            throw new Exception("Error creating seminars table: " . $conn->error);
        }

        // Create seminar_evaluations table if it doesn't exist
        $sql = "CREATE TABLE IF NOT EXISTS seminar_evaluations (
            evaluation_id INT AUTO_INCREMENT PRIMARY KEY,
            seminar_id INT NOT NULL,
            faculty_id INT NOT NULL,
            score DECIMAL(4,2) NOT NULL,
            remarks TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            evaluation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (seminar_id) REFERENCES seminars(seminar_id) ON DELETE CASCADE,
            FOREIGN KEY (faculty_id) REFERENCES users(user_id) ON DELETE CASCADE
        )";
        
        if ($conn->query($sql) === FALSE) {
            throw new Exception("Error creating seminar_evaluations table: " . $conn->error);
        }
        
        // Re-enable foreign key checks
        $conn->query("SET FOREIGN_KEY_CHECKS = 1");
        
        $conn->close();
        return true;
        
    } catch (Exception $e) {
        die("Setup failed: " . $e->getMessage());
    }
}

// Run database setup
createDatabase();
?> 