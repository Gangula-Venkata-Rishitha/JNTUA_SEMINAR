<?php
// Google Drive API Configuration
return [
    'client_id' => 'YOUR_CLIENT_ID',
    'client_secret' => 'YOUR_CLIENT_SECRET',
    'redirect_uri' => 'http://localhost/seminar/auth/google-callback.php',
    'scopes' => ['https://www.googleapis.com/auth/drive.file'],
    'folder_id' => 'YOUR_FOLDER_ID' // The Google Drive folder ID where videos will be stored
];
?> 