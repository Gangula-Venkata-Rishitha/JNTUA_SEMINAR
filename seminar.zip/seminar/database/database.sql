-- Create database if not exists
CREATE DATABASE IF NOT EXISTS seminar_db;
USE seminar_db;

-- Create Users table
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    role ENUM('student', 'faculty', 'hod') NOT NULL,
    department VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create Seminars table
CREATE TABLE IF NOT EXISTS seminars (
    seminar_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    video_url VARCHAR(255) NOT NULL,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    evaluation_status ENUM('pending', 'evaluated') DEFAULT 'pending',
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Create Seminar evaluations table
CREATE TABLE IF NOT EXISTS seminar_evaluations (
    evaluation_id INT PRIMARY KEY AUTO_INCREMENT,
    seminar_id INT NOT NULL,
    faculty_id INT NOT NULL,
    score DECIMAL(4,2) NOT NULL,
    remarks TEXT,
    evaluation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seminar_id) REFERENCES seminars(seminar_id) ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Insert default users with simple credentials
INSERT INTO users (username, password, full_name, email, role, department) VALUES
-- HOD user (username: hod, password: hod)
('hod', '$2y$10$6ouigvFyD4teK8k5AapFhOoASBIOnzuD5P9TOK7Uz5oAC8EMui7vO', 'HOD Test User', 'hod@test.com', 'hod', 'Computer Science'),

-- Faculty user (username: faculty, password: faculty)
('faculty', '$2y$10$cTSbK1OHwDPrcWxEqNsi9OyxJb3mRURlQDkhwFUFm1TWR6zCo4ZXC', 'Faculty Test User', 'faculty@test.com', 'faculty', 'Computer Science'),

-- Student user (username: 22001a0509, password: 22001a0509)
('22001a0509', '$2y$10$j0zJW0NVDQnYxLmiqYoB4ustnuRWLZWBcGAYiKeNePMIlitcCr7Iy', 'Student Test User', 'student@test.com', 'student', 'Computer Science');

-- Insert sample seminars
INSERT INTO seminars (student_id, title, description, video_url, evaluation_status) VALUES
((SELECT user_id FROM users WHERE username = '22001a0509'), 
'Introduction to Machine Learning', 
'A comprehensive overview of machine learning basics and applications', 
'uploads/seminars/sample1.mp4', 
'pending'),

((SELECT user_id FROM users WHERE username = '22001a0509'), 
'Web Security Best Practices', 
'Discussion on modern web security techniques and implementations', 
'uploads/seminars/sample2.mp4', 
'evaluated');

-- Insert sample evaluations
INSERT INTO seminar_evaluations (seminar_id, faculty_id, score, remarks) VALUES
(2, (SELECT user_id FROM users WHERE username = 'faculty'), 8.5, 'Excellent presentation with good practical examples. Could improve on time management.'); 