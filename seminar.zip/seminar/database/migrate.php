<?php
require_once '../config/database.php';

$conn = getDBConnection();

try {
    // Add created_at to seminars table if it doesn't exist
    $conn->query("ALTER TABLE seminars ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
    
    // Add created_at to seminar_evaluations table if it doesn't exist
    $conn->query("ALTER TABLE seminar_evaluations ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
    
    // Add created_at to users table if it doesn't exist
    $conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
    
    echo "Database migration completed successfully!";
} catch (Exception $e) {
    echo "Error during migration: " . $e->getMessage();
}

$conn->close();
?> 