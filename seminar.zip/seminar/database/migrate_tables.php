<?php
require_once __DIR__ . '/../config/database.php';

$conn = getDBConnection();

try {
    // Add created_at to seminars table if it doesn't exist
    $conn->query("ALTER TABLE seminars ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
    
    // Add updated_at to seminars table if it doesn't exist
    $conn->query("ALTER TABLE seminars ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
    
    echo "Database migration completed successfully!";
} catch (Exception $e) {
    echo "Error during migration: " . $e->getMessage();
}

$conn->close();
?> 