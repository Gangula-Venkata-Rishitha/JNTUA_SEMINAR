<?php
require_once __DIR__ . '/../config/database.php';

$conn = getDBConnection();

try {
    // Add thumbnail_url to seminars table if it doesn't exist
    $conn->query("ALTER TABLE seminars ADD COLUMN IF NOT EXISTS thumbnail_url VARCHAR(255) DEFAULT NULL");
    
    echo "Database migration completed successfully!";
} catch (Exception $e) {
    echo "Error during migration: " . $e->getMessage();
}

$conn->close();
?> 