<?php
// Redirect to HOD dashboard
header('Location: ../hod/dashboard.php');
exit();
?> 