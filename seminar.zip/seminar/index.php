<?php
require_once 'config/database.php';
session_start();

// If user is already logged in, redirect to their dashboard
if (isset($_SESSION['user_id'])) {
    $role = $_SESSION['role'];
    header("Location: ${role}/dashboard.php");
    exit;
}

// Get featured seminars
$conn = getDBConnection();
$featured_seminars = $conn->query("
    SELECT 
        s.seminar_id,
        s.title,
        s.description,
        s.video_url,
        u.full_name as student_name,
        u.department,
        se.score,
        f.full_name as faculty_name,
        se.remarks
    FROM seminars s
    JOIN users u ON s.student_id = u.user_id
    JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id
    JOIN users f ON se.faculty_id = f.user_id
    WHERE s.evaluation_status = 'evaluated'
    ORDER BY se.score DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SeminarHub - Academic Seminar Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="includes/styles/main.css">
    <link rel="stylesheet" href="https://cdn.plyr.io/3.7.2/plyr.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css">
</head>
<body>
    <!-- Hero Section -->
    <section class="hero">
        <nav class="navbar">
            <div class="nav-brand">
                <i class="fas fa-graduation-cap"></i>
                <span>SeminarHub</span>
            </div>
            <div class="nav-links">
                <a href="#features" class="nav-link">Features</a>
                <a href="#featured" class="nav-link">Featured</a>
                <a href="#about" class="nav-link">About</a>
            </div>
            <div class="nav-auth">
                <a href="login.php" class="btn-login">Login</a>
            </div>
        </nav>

        <div class="hero-content">
            <h1 class="animate-fade-in">Welcome to SeminarHub</h1>
            <p class="animate-slide-up">A modern platform for managing academic seminars, evaluations, and knowledge sharing.</p>
            <div class="hero-buttons animate-slide-up">
                <a href="login.php?role=student" class="btn-primary">
                    <i class="fas fa-user-graduate"></i> Student Login
                </a>
                <a href="login.php?role=faculty" class="btn-primary btn-outline">
                    <i class="fas fa-chalkboard-teacher"></i> Faculty Login
                </a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="features">
        <h2>Platform Features</h2>
        <div class="features-grid">
            <div class="feature-card animate-slide-up">
                <i class="fas fa-video"></i>
                <h3>Seminar Uploads</h3>
                <p>Upload and manage your academic seminar videos with ease</p>
            </div>
            <div class="feature-card animate-slide-up">
                <i class="fas fa-star"></i>
                <h3>Expert Evaluation</h3>
                <p>Get evaluated by experienced faculty members</p>
            </div>
            <div class="feature-card animate-slide-up">
                <i class="fas fa-chart-line"></i>
                <h3>Progress Tracking</h3>
                <p>Monitor your academic progress and performance</p>
            </div>
            <div class="feature-card animate-slide-up">
                <i class="fas fa-file-pdf"></i>
                <h3>Detailed Reports</h3>
                <p>Generate comprehensive performance reports</p>
            </div>
        </div>
    </section>

    <!-- Featured Seminars Section -->
    <section id="featured" class="featured-seminars">
        <h2>Featured Seminars</h2>
        <div class="swiper seminar-slider">
            <div class="swiper-wrapper">
                <?php while ($seminar = $featured_seminars->fetch_assoc()): ?>
                    <div class="swiper-slide">
                        <div class="seminar-card">
                            <div class="video-container">
                                <video 
                                    class="plyr-video"
                                    playsinline
                                    controls
                                    data-poster="uploads/thumbnails/<?php echo basename($seminar['video_url'], '.mp4') ?>.jpg"
                                >
                                    <source src="<?php echo htmlspecialchars($seminar['video_url']); ?>" type="video/mp4">
                                </video>
                            </div>
                            <div class="seminar-info">
                                <h3><?php echo htmlspecialchars($seminar['title']); ?></h3>
                                <p class="student-name">
                                    <i class="fas fa-user-graduate"></i>
                                    <?php echo htmlspecialchars($seminar['student_name']); ?>
                                </p>
                                <p class="department">
                                    <i class="fas fa-university"></i>
                                    <?php echo htmlspecialchars($seminar['department']); ?>
                                </p>
                                <div class="evaluation">
                                    <div class="score">
                                        <span class="label">Score:</span>
                                        <span class="value"><?php echo number_format($seminar['score'], 1); ?>/10</span>
                                    </div>
                                    <div class="faculty">
                                        <span class="label">Evaluated by:</span>
                                        <span class="value"><?php echo htmlspecialchars($seminar['faculty_name']); ?></span>
                                    </div>
                                </div>
                                <p class="remarks"><?php echo htmlspecialchars($seminar['remarks']); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="about-content">
            <h2>About SeminarHub</h2>
            <p>SeminarHub is a modern academic platform designed to streamline the process of seminar management, evaluation, and knowledge sharing. Our platform provides a seamless experience for students to showcase their academic presentations and receive valuable feedback from faculty members.</p>
            <div class="stats">
                <div class="stat-item">
                    <span class="value"><?php echo $conn->query("SELECT COUNT(*) as count FROM seminars")->fetch_assoc()['count']; ?>+</span>
                    <span class="label">Seminars</span>
                </div>
                <div class="stat-item">
                    <span class="value"><?php echo $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'faculty'")->fetch_assoc()['count']; ?>+</span>
                    <span class="label">Faculty</span>
                </div>
                <div class="stat-item">
                    <span class="value"><?php echo $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'student'")->fetch_assoc()['count']; ?>+</span>
                    <span class="label">Students</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="#features">Features</a>
                <a href="#featured">Featured Seminars</a>
                <a href="#about">About Us</a>
            </div>
            <div class="footer-section">
                <h3>Login</h3>
                <a href="login.php?role=student">Student Login</a>
                <a href="login.php?role=faculty">Faculty Login</a>
                <a href="login.php?role=hod">HOD Login</a>
            </div>
            <div class="footer-section">
                <h3>Contact</h3>
                <p><i class="fas fa-envelope"></i> support@seminarhub.com</p>
                <p><i class="fas fa-phone"></i> +1-234-567-8900</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 SeminarHub. All rights reserved.</p>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.plyr.io/3.7.2/plyr.polyfilled.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
    <script>
        // Initialize video players
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Plyr for all videos
            const players = Array.from(document.querySelectorAll('.plyr-video')).map(p => new Plyr(p, {
                controls: ['play', 'progress', 'current-time', 'mute', 'volume', 'fullscreen'],
                hideControls: true,
                resetOnEnd: true
            }));

            // Initialize Swiper
            const swiper = new Swiper('.seminar-slider', {
                slidesPerView: 1,
                spaceBetween: 30,
                loop: true,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true
                },
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev'
                },
                breakpoints: {
                    768: {
                        slidesPerView: 2
                    },
                    1024: {
                        slidesPerView: 3
                    }
                },
                on: {
                    slideChange: function() {
                        // Pause all videos when sliding
                        players.forEach(player => player.pause());
                    }
                }
            });

            // Smooth scroll for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });
        });
    </script>

    <style>
        .hero {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 4rem 2rem;
            text-align: center;
            min-height: 80vh;
            display: flex;
            flex-direction: column;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            margin-bottom: 4rem;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.5rem;
            font-weight: 600;
        }

        .nav-links {
            display: flex;
            gap: 2rem;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
        }

        .nav-link:hover {
            opacity: 0.8;
        }

        .btn-login {
            background: white;
            color: var(--primary-color);
            padding: 0.5rem 1.5rem;
            border-radius: var(--border-radius);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 255, 255, 0.2);
        }

        .hero-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            max-width: 800px;
            margin: 0 auto;
        }

        .hero-content h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .hero-content p {
            font-size: 1.2rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }

        .hero-buttons {
            display: flex;
            gap: 1rem;
        }

        .btn-outline {
            background: transparent;
            border: 2px solid white;
            color: white;
        }

        .features {
            padding: 4rem 2rem;
            background: white;
        }

        .features h2 {
            text-align: center;
            margin-bottom: 3rem;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .feature-card {
            text-align: center;
            padding: 2rem;
            background: var(--light-bg);
            border-radius: var(--border-radius);
            transition: var(--transition);
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--box-shadow);
        }

        .feature-card i {
            font-size: 2.5rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .featured-seminars {
            padding: 4rem 2rem;
            background: var(--light-bg);
        }

        .featured-seminars h2 {
            text-align: center;
            margin-bottom: 3rem;
        }

        .seminar-slider {
            max-width: 1200px;
            margin: 0 auto;
            padding: 1rem;
        }

        .seminar-card {
            background: white;
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--box-shadow);
        }

        .video-container {
            position: relative;
            padding-top: 56.25%;
        }

        .plyr-video {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        .seminar-info {
            padding: 1.5rem;
        }

        .seminar-info h3 {
            margin-bottom: 1rem;
            color: var(--text-color);
        }

        .student-name, .department {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #666;
            margin-bottom: 0.5rem;
        }

        .evaluation {
            background: var(--light-bg);
            padding: 1rem;
            border-radius: var(--border-radius);
            margin: 1rem 0;
        }

        .score, .faculty {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }

        .remarks {
            font-style: italic;
            color: #666;
        }

        .about {
            padding: 4rem 2rem;
            background: white;
        }

        .about-content {
            max-width: 800px;
            margin: 0 auto;
            text-align: center;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 2rem;
            margin-top: 3rem;
        }

        .stat-item {
            text-align: center;
        }

        .stat-item .value {
            font-size: 2.5rem;
            font-weight: 600;
            color: var(--primary-color);
            display: block;
        }

        .footer {
            background: var(--text-color);
            color: white;
            padding: 4rem 2rem 2rem;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .footer-section h3 {
            margin-bottom: 1rem;
        }

        .footer-section a {
            color: white;
            text-decoration: none;
            display: block;
            margin-bottom: 0.5rem;
            opacity: 0.8;
            transition: var(--transition);
        }

        .footer-section a:hover {
            opacity: 1;
        }

        .footer-bottom {
            text-align: center;
            margin-top: 3rem;
            padding-top: 2rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        @media (max-width: 768px) {
            .hero-content h1 {
                font-size: 2rem;
            }

            .hero-buttons {
                flex-direction: column;
            }

            .nav-links {
                display: none;
            }

            .stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
</body>
</html>
<?php $conn->close(); ?> 