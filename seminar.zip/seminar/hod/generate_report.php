<?php
require_once 'includes/header.php';
require_once '../config/database.php';
require_once '../includes/pdf_generator.php';

$conn = getDBConnection();

// Handle report generation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $report_type = $_POST['report_type'];
    $pdf = new SeminarReportPDF('P', 'mm', 'A4', true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator('SeminarHub');
    $pdf->SetAuthor('HOD');
    $pdf->SetTitle('Department Report');
    
    // Set margins
    $pdf->SetMargins(10, 20, 10);
    $pdf->SetAutoPageBreak(TRUE, 15);
    
    // Add a page
    $pdf->AddPage();
    
    if ($report_type === 'faculty') {
        // Generate Faculty Report
        $pdf->SectionTitle('Faculty Performance Report');
        
        // Get faculty statistics
        $stmt = $conn->prepare("
            SELECT u.full_name, u.username, u.department,
                   COUNT(se.evaluation_id) as evaluations_count,
                   AVG(se.score) as avg_score
            FROM users u
            LEFT JOIN seminar_evaluations se ON u.user_id = se.faculty_id
            WHERE u.role = 'faculty'
            GROUP BY u.user_id
            ORDER BY evaluations_count DESC
        ");
        $stmt->execute();
        $faculties = $stmt->get_result();
        
        // Add table headers
        $pdf->TableHeader(['Name', 'ID', 'Department', 'Evaluations', 'Avg Score']);
        
        // Add faculty data
        while ($faculty = $faculties->fetch_assoc()) {
            $pdf->TableRow([
                $faculty['full_name'],
                $faculty['username'],
                $faculty['department'],
                $faculty['evaluations_count'],
                number_format($faculty['avg_score'] ?? 0, 2)
            ]);
        }
        
    } else if ($report_type === 'student') {
        // Generate Student Report
        $pdf->SectionTitle('Student Performance Report');
        
        // Get student statistics
        $stmt = $conn->prepare("
            SELECT u.full_name, u.username, u.department,
                   COUNT(s.seminar_id) as seminars_count,
                   AVG(se.score) as avg_score
            FROM users u
            LEFT JOIN seminars s ON u.user_id = s.student_id
            LEFT JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id
            WHERE u.role = 'student'
            GROUP BY u.user_id
            ORDER BY avg_score DESC
        ");
        $stmt->execute();
        $students = $stmt->get_result();
        
        // Add table headers
        $pdf->TableHeader(['Name', 'Roll No', 'Department', 'Seminars', 'Avg Score']);
        
        // Add student data
        while ($student = $students->fetch_assoc()) {
            $pdf->TableRow([
                $student['full_name'],
                $student['username'],
                $student['department'],
                $student['seminars_count'],
                number_format($student['avg_score'] ?? 0, 2)
            ]);
        }
    }
    
    // Add department statistics
    $stats = [
        'Total Faculty' => $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'faculty'")->fetch_assoc()['count'],
        'Total Students' => $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'student'")->fetch_assoc()['count'],
        'Total Seminars' => $conn->query("SELECT COUNT(*) as count FROM seminars")->fetch_assoc()['count'],
        'Evaluated Seminars' => $conn->query("SELECT COUNT(*) as count FROM seminars WHERE evaluation_status = 'evaluated'")->fetch_assoc()['count']
    ];
    $pdf->StatisticsSection($stats);
    
    // Output PDF
    $pdf->Output('department_report.pdf', 'D');
    exit;
}
?>

<div class="report-container">
    <div class="page-header animate-fade-in">
        <h2><i class="fas fa-file-pdf"></i> Generate Reports</h2>
        <p>Generate detailed reports for faculty and student performance</p>
    </div>

    <div class="report-cards animate-slide-up">
        <div class="report-card">
            <div class="card-icon">
                <i class="fas fa-chalkboard-teacher"></i>
            </div>
            <div class="card-content">
                <h3>Faculty Report</h3>
                <p>Generate a comprehensive report of faculty performance and evaluation statistics</p>
                <form method="POST">
                    <input type="hidden" name="report_type" value="faculty">
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-download"></i> Download Report
                    </button>
                </form>
            </div>
        </div>

        <div class="report-card">
            <div class="card-icon">
                <i class="fas fa-user-graduate"></i>
            </div>
            <div class="card-content">
                <h3>Student Report</h3>
                <p>Generate a detailed report of student seminar performances and scores</p>
                <form method="POST">
                    <input type="hidden" name="report_type" value="student">
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-download"></i> Download Report
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    .report-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem;
    }

    .page-header {
        text-align: center;
        margin-bottom: 3rem;
    }

    .page-header h2 {
        color: var(--text-color);
        margin-bottom: 0.5rem;
    }

    .page-header p {
        color: #666;
    }

    .report-cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 2rem;
    }

    .report-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        padding: 2rem;
        text-align: center;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .report-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }

    .card-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 1.5rem;
        background: var(--light-bg);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .card-icon i {
        font-size: 2rem;
        color: var(--primary-color);
    }

    .card-content h3 {
        color: var(--text-color);
        margin-bottom: 1rem;
    }

    .card-content p {
        color: #666;
        margin-bottom: 1.5rem;
        line-height: 1.5;
    }

    @media (max-width: 768px) {
        .report-container {
            padding: 1rem;
        }

        .report-cards {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php
require_once 'includes/footer.php';
$conn->close();
?> 