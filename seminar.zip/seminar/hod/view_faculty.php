<?php
require_once 'includes/header.php';
require_once '../config/database.php';

$conn = getDBConnection();

// Get all departments for filter
$departments = $conn->query("SELECT DISTINCT department FROM users WHERE role = 'faculty' ORDER BY department");

// Get faculty members with search and filter
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter_dept = isset($_GET['department']) ? trim($_GET['department']) : '';

$query = "SELECT user_id, username, full_name, email, department, created_at FROM users WHERE role = 'faculty'";
if ($search) {
    $search = "%$search%";
    $query .= " AND (full_name LIKE ? OR email LIKE ? OR department LIKE ?)";
}
if ($filter_dept) {
    $query .= " AND department = ?";
}
$query .= " ORDER BY full_name";

$stmt = $conn->prepare($query);

if ($search && $filter_dept) {
    $stmt->bind_param("ssss", $search, $search, $search, $filter_dept);
} elseif ($search) {
    $stmt->bind_param("sss", $search, $search, $search);
} elseif ($filter_dept) {
    $stmt->bind_param("s", $filter_dept);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<div class="content-header">
    <h1>Faculty Members</h1>
    <div class="actions">
        <a href="register_faculty.php" class="btn-primary">
            <i class="fas fa-plus"></i> Add New Faculty
        </a>
        <button onclick="generatePDF()" class="btn-secondary">
            <i class="fas fa-download"></i> Export PDF
        </button>
    </div>
</div>

<div class="filters">
    <div class="search-box">
        <i class="fas fa-search"></i>
        <input type="text" class="search-input" placeholder="Search faculty..." value="<?php echo htmlspecialchars($search); ?>">
    </div>
    
    <select class="filter-select">
        <option value="">All Departments</option>
        <?php while ($dept = $departments->fetch_assoc()): ?>
            <option value="<?php echo htmlspecialchars($dept['department']); ?>"
                    <?php echo $filter_dept === $dept['department'] ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($dept['department']); ?>
            </option>
        <?php endwhile; ?>
    </select>
</div>

<div class="table-container">
    <table class="data-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Department</th>
                <th>Joined Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($faculty = $result->fetch_assoc()): ?>
                <tr data-department="<?php echo htmlspecialchars(strtolower($faculty['department'])); ?>">
                    <td>
                        <div class="user-info">
                            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($faculty['full_name']); ?>&size=40" alt="Avatar">
                            <div>
                                <div class="user-name"><?php echo htmlspecialchars($faculty['full_name']); ?></div>
                                <div class="user-username"><?php echo htmlspecialchars($faculty['username']); ?></div>
                            </div>
                        </div>
                    </td>
                    <td><?php echo htmlspecialchars($faculty['email']); ?></td>
                    <td><?php echo htmlspecialchars($faculty['department']); ?></td>
                    <td><?php echo date('M d, Y', strtotime($faculty['created_at'])); ?></td>
                    <td>
                        <div class="actions">
                            <button onclick="editFaculty(<?php echo $faculty['user_id']; ?>)" class="btn-icon" title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="viewDetails(<?php echo $faculty['user_id']; ?>)" class="btn-icon" title="View Details">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button onclick="resetPassword(<?php echo $faculty['user_id']; ?>)" class="btn-icon" title="Reset Password">
                                <i class="fas fa-key"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<style>
    .content-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
    }

    .actions {
        display: flex;
        gap: 1rem;
    }

    .btn-primary, .btn-secondary {
        padding: 0.5rem 1rem;
        border-radius: 5px;
        border: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.9rem;
        transition: all 0.3s;
    }

    .btn-primary {
        background: var(--primary-color);
        color: white;
    }

    .btn-secondary {
        background: var(--light-bg);
        color: var(--text-color);
    }

    .btn-primary:hover {
        background: var(--secondary-color);
    }

    .btn-secondary:hover {
        background: #e9ecef;
    }

    .filters {
        display: flex;
        gap: 1rem;
        margin-bottom: 2rem;
    }

    .search-box {
        flex: 1;
        position: relative;
    }

    .search-box i {
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: #666;
    }

    .search-input {
        width: 100%;
        padding: 0.8rem 1rem 0.8rem 2.5rem;
        border: 1px solid var(--border-color);
        border-radius: 5px;
        font-size: 0.9rem;
    }

    .filter-select {
        padding: 0.8rem;
        border: 1px solid var(--border-color);
        border-radius: 5px;
        font-size: 0.9rem;
        min-width: 200px;
    }

    .table-container {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        overflow: hidden;
    }

    .data-table {
        width: 100%;
        border-collapse: collapse;
    }

    .data-table th {
        background: var(--light-bg);
        padding: 1rem;
        text-align: left;
        font-weight: 600;
        color: var(--text-color);
    }

    .data-table td {
        padding: 1rem;
        border-bottom: 1px solid var(--border-color);
    }

    .user-info {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .user-info img {
        width: 40px;
        height: 40px;
        border-radius: 50%;
    }

    .user-username {
        font-size: 0.85rem;
        color: #666;
    }

    .btn-icon {
        background: none;
        border: none;
        color: #666;
        cursor: pointer;
        padding: 0.5rem;
        border-radius: 5px;
        transition: all 0.3s;
    }

    .btn-icon:hover {
        background: var(--light-bg);
        color: var(--primary-color);
    }

    @media (max-width: 768px) {
        .filters {
            flex-direction: column;
        }
        
        .content-header {
            flex-direction: column;
            gap: 1rem;
        }
        
        .data-table {
            display: block;
            overflow-x: auto;
        }
    }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
<script>
    function editFaculty(userId) {
        // Implement edit functionality
        window.location.href = `edit_faculty.php?id=${userId}`;
    }

    function viewDetails(userId) {
        // Implement view details functionality
        window.location.href = `faculty_details.php?id=${userId}`;
    }

    function resetPassword(userId) {
        if (confirm('Are you sure you want to reset this faculty member\'s password?')) {
            // Implement password reset functionality
            fetch(`reset_password.php?id=${userId}`, {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Password has been reset successfully.');
                } else {
                    alert('Error resetting password.');
                }
            });
        }
    }

    function generatePDF() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        // Add title
        doc.setFontSize(18);
        doc.text('Faculty Members Report', 20, 20);
        
        // Get table data
        const rows = Array.from(document.querySelectorAll('tbody tr')).filter(row => row.style.display !== 'none');
        
        // Define columns
        const columns = ['Name', 'Email', 'Department', 'Joined Date'];
        
        // Create table data
        const data = rows.map(row => [
            row.querySelector('.user-name').textContent,
            row.cells[1].textContent,
            row.cells[2].textContent,
            row.cells[3].textContent
        ]);
        
        // Add table
        doc.autoTable({
            head: [columns],
            body: data,
            startY: 30,
            styles: { fontSize: 10 },
            headStyles: { fillColor: [74, 144, 226] }
        });
        
        // Save PDF
        doc.save('faculty-report.pdf');
    }
</script>

<?php
require_once 'includes/footer.php';
$conn->close();
?> 