<?php
require_once '../includes/auth.php';
$user = checkAuth('hod');

// Get current page for active menu highlighting
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOD Dashboard - Seminar Management System</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --sidebar-width: 250px;
            --navbar-height: 60px;
            --primary-color: #4a90e2;
            --secondary-color: #ff69b4;
            --text-color: #333;
            --light-bg: #f8f9fa;
            --border-color: #dee2e6;
            --shadow-color: rgba(0,0,0,0.1);
        }

        .dashboard-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: white;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: transform 0.3s ease;
        }

        .sidebar-header {
            padding: 1rem;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            text-align: center;
        }

        .sidebar-menu {
            padding: 1rem 0;
        }

        .menu-item {
            padding: 0.75rem 1.5rem;
            display: flex;
            align-items: center;
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s;
        }

        .menu-item i {
            width: 20px;
            margin-right: 10px;
        }

        .menu-item:hover,
        .menu-item.active {
            background: var(--light-bg);
            color: var(--primary-color);
        }

        /* Navbar Styles */
        .navbar {
            position: fixed;
            top: 0;
            right: 0;
            width: calc(100% - var(--sidebar-width));
            height: var(--navbar-height);
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 2rem;
            z-index: 100;
        }

        .navbar-brand {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--primary-color);
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-info {
            text-align: right;
        }

        .user-name {
            font-weight: 600;
            color: var(--text-color);
        }

        .user-role {
            font-size: 0.85rem;
            color: #666;
        }

        /* Main Content Area */
        .main-content {
            margin-left: var(--sidebar-width);
            margin-top: var(--navbar-height);
            padding: 2rem;
            width: calc(100% - var(--sidebar-width));
        }

        /* Common Button Styles */
        .btn-primary, .btn-secondary {
            padding: 0.5rem 1rem;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            transition: all 0.3s;
            text-decoration: none;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-secondary {
            background: var(--light-bg);
            color: var(--text-color);
        }

        .btn-primary:hover {
            background: #357abd;
        }

        .btn-secondary:hover {
            background: #e2e6ea;
        }

        /* Mobile Responsiveness */
        .menu-toggle {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .navbar {
                width: 100%;
            }

            .main-content {
                margin-left: 0;
                width: 100%;
            }

            .menu-toggle {
                display: block;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>SeminarHub</h2>
            </div>
            <nav class="sidebar-menu">
                <a href="dashboard.php" class="menu-item <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="register_faculty.php" class="menu-item <?php echo $current_page == 'register_faculty.php' ? 'active' : ''; ?>">
                    <i class="fas fa-chalkboard-teacher"></i> Register Faculty
                </a>
                <a href="view_faculty.php" class="menu-item <?php echo $current_page == 'view_faculty.php' ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i> View Faculty
                </a>
                <a href="view_students.php" class="menu-item <?php echo $current_page == 'view_students.php' ? 'active' : ''; ?>">
                    <i class="fas fa-user-graduate"></i> View Students
                </a>
                <a href="view_seminars.php" class="menu-item <?php echo $current_page == 'view_seminars.php' ? 'active' : ''; ?>">
                    <i class="fas fa-video"></i> View Seminars
                </a>
                <a href="reports.php" class="menu-item <?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
                    <i class="fas fa-chart-bar"></i> Reports
                </a>
                <a href="../logout.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </nav>
        </aside>

        <!-- Navbar -->
        <nav class="navbar">
            <div class="menu-toggle">
                <i class="fas fa-bars"></i>
            </div>
            <div class="navbar-brand">
                HOD Dashboard
            </div>
            <div class="user-menu">
                <div class="user-info">
                    <div class="user-name"><?php echo htmlspecialchars($user['full_name']); ?></div>
                    <div class="user-role">Head of Department - <?php echo htmlspecialchars($user['department']); ?></div>
                </div>
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['full_name']); ?>&background=4a90e2&color=fff" 
                     alt="Profile" 
                     style="width: 40px; height: 40px; border-radius: 50%;">
            </div>
        </nav>

        <!-- Main Content -->
        <main class="main-content"> 