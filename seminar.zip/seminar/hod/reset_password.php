<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

// Check if user is HOD
$user = checkAuth('hod');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$user_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid user ID']);
    exit();
}

$conn = getDBConnection();

// Verify user is a faculty member
$stmt = $conn->prepare("SELECT username FROM users WHERE user_id = ? AND role = 'faculty'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo json_encode(['success' => false, 'message' => 'Faculty member not found']);
    exit();
}

// Generate a random temporary password
$temp_password = bin2hex(random_bytes(4)); // 8 characters
$hashed_password = password_hash($temp_password, PASSWORD_DEFAULT);

// Update the password
$stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
$stmt->bind_param("si", $hashed_password, $user_id);

if ($stmt->execute()) {
    // Get faculty email for notification
    $faculty = $result->fetch_assoc();
    
    // In a production environment, you would send an email here
    // mail($faculty['email'], 'Password Reset', "Your temporary password is: $temp_password");
    
    echo json_encode([
        'success' => true, 
        'message' => 'Password reset successful',
        'temp_password' => $temp_password // In production, this should be sent via email only
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Error resetting password']);
}

$stmt->close();
$conn->close();
?> 