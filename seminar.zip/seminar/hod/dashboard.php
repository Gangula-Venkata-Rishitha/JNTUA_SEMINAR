<?php
require_once 'includes/header.php';
require_once '../config/database.php';

$conn = getDBConnection();

// Get department statistics
$department = $user['department'];

// Get total faculty count
$stmt = $conn->prepare("SELECT COUNT(*) as faculty_count FROM users WHERE department = ? AND role = 'faculty'");
$stmt->bind_param("s", $department);
$stmt->execute();
$faculty_count = $stmt->get_result()->fetch_assoc()['faculty_count'];

// Get total students count
$stmt = $conn->prepare("SELECT COUNT(*) as student_count FROM users WHERE department = ? AND role = 'student'");
$stmt->bind_param("s", $department);
$stmt->execute();
$student_count = $stmt->get_result()->fetch_assoc()['student_count'];

// Get total seminars count
$stmt = $conn->prepare("
    SELECT COUNT(*) as seminar_count 
    FROM seminars s 
    JOIN users u ON s.student_id = u.user_id 
    WHERE u.department = ?
");
$stmt->bind_param("s", $department);
$stmt->execute();
$seminar_count = $stmt->get_result()->fetch_assoc()['seminar_count'];

// Get pending evaluations count
$stmt = $conn->prepare("
    SELECT COUNT(*) as pending_count 
    FROM seminars s 
    JOIN users u ON s.student_id = u.user_id 
    WHERE u.department = ? AND s.evaluation_status = 'pending'
");
$stmt->bind_param("s", $department);
$stmt->execute();
$pending_count = $stmt->get_result()->fetch_assoc()['pending_count'];

// Get recent seminars
$stmt = $conn->prepare("
    SELECT 
        s.seminar_id,
        s.title,
        s.evaluation_status,
        u.full_name as student_name,
        s.created_at
    FROM seminars s 
    JOIN users u ON s.student_id = u.user_id 
    WHERE u.department = ?
    ORDER BY s.created_at DESC 
    LIMIT 5
");
$stmt->bind_param("s", $department);
$stmt->execute();
$recent_seminars = $stmt->get_result();
?>

<div class="dashboard-container">
    <!-- Welcome Section -->
    <div class="welcome-section">
        <h2>Welcome, <?php echo htmlspecialchars($user['full_name']); ?>!</h2>
        <p>Head of Department - <?php echo htmlspecialchars($department); ?></p>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-chalkboard-teacher"></i>
            </div>
            <div class="stat-details">
                <h3>Faculty Members</h3>
                <p class="stat-number"><?php echo $faculty_count; ?></p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-user-graduate"></i>
            </div>
            <div class="stat-details">
                <h3>Students</h3>
                <p class="stat-number"><?php echo $student_count; ?></p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-video"></i>
            </div>
            <div class="stat-details">
                <h3>Total Seminars</h3>
                <p class="stat-number"><?php echo $seminar_count; ?></p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-details">
                <h3>Pending Evaluations</h3>
                <p class="stat-number"><?php echo $pending_count; ?></p>
            </div>
        </div>
    </div>

    <!-- Recent Seminars Section -->
    <div class="recent-seminars">
        <div class="section-header">
            <h3><i class="fas fa-history"></i> Recent Seminars</h3>
        </div>
        <?php if ($recent_seminars->num_rows > 0): ?>
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Student</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($seminar = $recent_seminars->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($seminar['title']); ?></td>
                        <td><?php echo htmlspecialchars($seminar['student_name']); ?></td>
                        <td><?php echo date('M d, Y', strtotime($seminar['created_at'])); ?></td>
                        <td>
                            <span class="status-badge <?php echo $seminar['evaluation_status']; ?>">
                                <?php echo ucfirst($seminar['evaluation_status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="view_seminar.php?id=<?php echo $seminar['seminar_id']; ?>" class="btn-icon">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-video-slash"></i>
            <p>No seminars uploaded yet</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
    .dashboard-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem;
    }

    .welcome-section {
        margin-bottom: 2rem;
    }

    .welcome-section h2 {
        color: var(--text-color);
        margin-bottom: 0.5rem;
    }

    .welcome-section p {
        color: #666;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .stat-card {
        background: white;
        border-radius: 10px;
        padding: 1.5rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .stat-icon {
        width: 50px;
        height: 50px;
        background: var(--light-bg);
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        color: var(--primary-color);
    }

    .stat-details h3 {
        color: #666;
        font-size: 0.9rem;
        margin-bottom: 0.25rem;
    }

    .stat-number {
        color: var(--text-color);
        font-size: 1.5rem;
        font-weight: 600;
    }

    .recent-seminars {
        background: white;
        border-radius: 10px;
        padding: 1.5rem;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .section-header {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 1.5rem;
    }

    .section-header h3 {
        color: var(--text-color);
        font-size: 1.25rem;
    }

    .data-table {
        width: 100%;
        border-collapse: collapse;
    }

    .data-table th,
    .data-table td {
        padding: 1rem;
        text-align: left;
        border-bottom: 1px solid var(--border-color);
    }

    .data-table th {
        background: var(--light-bg);
        font-weight: 600;
        color: var(--text-color);
    }

    .status-badge {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        border-radius: 15px;
        font-size: 0.85rem;
        font-weight: 500;
    }

    .status-badge.pending {
        background: #fff3cd;
        color: #856404;
    }

    .status-badge.evaluated {
        background: #d4edda;
        color: #155724;
    }

    .btn-icon {
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 5px;
        color: var(--primary-color);
        background: var(--light-bg);
        text-decoration: none;
        transition: all 0.3s;
    }

    .btn-icon:hover {
        background: var(--primary-color);
        color: white;
    }

    .empty-state {
        text-align: center;
        padding: 2rem;
        color: #666;
    }

    .empty-state i {
        font-size: 3rem;
        color: var(--border-color);
        margin-bottom: 1rem;
    }

    @media (max-width: 768px) {
        .dashboard-container {
            padding: 1rem;
        }

        .stats-grid {
            grid-template-columns: 1fr;
        }

        .data-table {
            display: block;
            overflow-x: auto;
            white-space: nowrap;
        }
    }
</style>

<?php
$stmt->close();
$conn->close();
require_once 'includes/footer.php';
?> 