<?php
ob_start(); // Start output buffering at the very beginning
require_once 'includes/header.php';
require_once '../config/database.php';
require_once __DIR__ . '/../vendor/autoload.php';

// Remove the use statement and directly reference TCPDF with full namespace
// use TCPDF;  // Remove this line

$conn = getDBConnection();
$success_message = '';
$error_message = '';

// Get student ID from URL if provided
$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : null;

// Handle PDF generation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_pdf'])) {
    // Clean any output that might have been sent
    ob_end_clean();
    
    try {
        // Create new PDF document with full namespace reference
        $pdf = new \TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        
        // Define PDF constants if they're not defined
        if (!defined('PDF_PAGE_ORIENTATION')) {
            define('PDF_PAGE_ORIENTATION', 'P');
        }
        if (!defined('PDF_UNIT')) {
            define('PDF_UNIT', 'mm');
        }
        if (!defined('PDF_PAGE_FORMAT')) {
            define('PDF_PAGE_FORMAT', 'A4');
        }
        if (!defined('PDF_CREATOR')) {
            define('PDF_CREATOR', 'Seminar System');
        }
        
        // Set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('Seminar System');
        $pdf->SetTitle('Report');
        
        // Remove default header/footer
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        
        // Set margins
        $pdf->SetMargins(15, 15, 15);
        $pdf->SetAutoPageBreak(true, 15);
        
        // Add a page
        $pdf->AddPage();
        
        // Set font
        $pdf->SetFont('helvetica', 'B', 20);
        
        // Department header
        $pdf->Cell(0, 10, $user['department'] . ' Department', 0, 1, 'C');
        $pdf->Cell(0, 10, 'Performance Report', 0, 1, 'C');
        $pdf->Ln(10);
        
        // Get department statistics
        $stats_stmt = $conn->prepare("
            SELECT 
                COUNT(DISTINCT u.user_id) as total_students,
                COUNT(DISTINCT CASE WHEN s.seminar_id IS NOT NULL THEN u.user_id END) as active_students,
                COUNT(s.seminar_id) as total_seminars,
                COUNT(CASE WHEN s.evaluation_status = 'evaluated' THEN 1 END) as evaluated_seminars,
                ROUND(AVG(CASE WHEN s.evaluation_status = 'evaluated' THEN 
                    (SELECT score FROM seminar_evaluations WHERE seminar_id = s.seminar_id)
                END), 1) as dept_avg_score
            FROM users u
            LEFT JOIN seminars s ON u.user_id = s.student_id
            WHERE u.role = 'student' AND u.department = ?
        ");
        
        $stats_stmt->bind_param("s", $user['department']);
        $stats_stmt->execute();
        $stats = $stats_stmt->get_result()->fetch_assoc();
        
        // Add department statistics
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->Cell(0, 10, 'Department Overview', 0, 1, 'L');
        $pdf->SetFont('helvetica', '', 12);
        $pdf->Ln(5);
        
        $stats_html = '
        <table border="0" cellpadding="5">
            <tr>
                <td width="200">Total Students:</td>
                <td>' . $stats['total_students'] . '</td>
            </tr>
            <tr>
                <td>Active Students:</td>
                <td>' . $stats['active_students'] . '</td>
            </tr>
            <tr>
                <td>Total Seminars:</td>
                <td>' . $stats['total_seminars'] . '</td>
            </tr>
            <tr>
                <td>Evaluated Seminars:</td>
                <td>' . $stats['evaluated_seminars'] . '</td>
            </tr>
            <tr>
                <td>Department Average:</td>
                <td>' . ($stats['dept_avg_score'] ?? 'N/A') . '</td>
            </tr>
        </table>';
        
        $pdf->writeHTML($stats_html, true, false, true, false, '');
        $pdf->Ln(10);
        
        // Get student performance data
        $students_stmt = $conn->prepare("
            SELECT 
                u.user_id,
                u.username,
                u.full_name,
                COUNT(s.seminar_id) as total_seminars,
                COUNT(CASE WHEN s.evaluation_status = 'evaluated' THEN 1 END) as evaluated_seminars,
                ROUND(AVG(CASE WHEN s.evaluation_status = 'evaluated' THEN 
                    (SELECT score FROM seminar_evaluations WHERE seminar_id = s.seminar_id)
                END), 1) as avg_score
            FROM users u
            LEFT JOIN seminars s ON u.user_id = s.student_id
            WHERE u.role = 'student' AND u.department = ?
            GROUP BY u.user_id
            ORDER BY COALESCE(AVG(CASE WHEN s.evaluation_status = 'evaluated' THEN 
                (SELECT score FROM seminar_evaluations WHERE seminar_id = s.seminar_id)
            END), -1) DESC, u.full_name
        ");
        
        $students_stmt->bind_param("s", $user['department']);
        $students_stmt->execute();
        $students = $students_stmt->get_result();
        
        // Add student performance table
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->Cell(0, 10, 'Student Performance', 0, 1, 'L');
        $pdf->Ln(5);
        
        $table_html = '
        <table border="1" cellpadding="5">
            <thead>
                <tr style="background-color: #f5f5f5;">
                    <th width="40">#</th>
                    <th width="100">Roll Number</th>
                    <th width="180">Student Name</th>
                    <th width="80">Seminars</th>
                    <th width="80">Evaluated</th>
                    <th width="80">Avg. Score</th>
                </tr>
            </thead>
            <tbody>';
        
        $i = 1;
        while ($student = $students->fetch_assoc()) {
            $table_html .= '
            <tr>
                <td>' . $i++ . '</td>
                <td>' . htmlspecialchars($student['username']) . '</td>
                <td>' . htmlspecialchars($student['full_name']) . '</td>
                <td align="center">' . $student['total_seminars'] . '</td>
                <td align="center">' . $student['evaluated_seminars'] . '</td>
                <td align="center">' . ($student['avg_score'] ?? 'N/A') . '</td>
            </tr>';
        }
        
        $table_html .= '
            </tbody>
        </table>';
        
        $pdf->writeHTML($table_html, true, false, true, false, '');
        
        // Close database statements
        $stats_stmt->close();
        if (isset($students_stmt)) {
            $students_stmt->close();
        }
        
        // Output the PDF
        $pdf->Output('department_performance_report.pdf', 'D');
        exit;
    } catch (Exception $e) {
        $error_message = "Error generating PDF: " . $e->getMessage();
    }
}

// Get department statistics for display
$stats_stmt = $conn->prepare("
    SELECT 
        COUNT(DISTINCT u.user_id) as total_students,
        COUNT(DISTINCT CASE WHEN s.seminar_id IS NOT NULL THEN u.user_id END) as active_students,
        COUNT(s.seminar_id) as total_seminars,
        COUNT(CASE WHEN s.evaluation_status = 'evaluated' THEN 1 END) as evaluated_seminars,
        ROUND(AVG(CASE WHEN s.evaluation_status = 'evaluated' THEN 
            (SELECT score FROM seminar_evaluations WHERE seminar_id = s.seminar_id)
        END), 1) as dept_avg_score
    FROM users u
    LEFT JOIN seminars s ON u.user_id = s.student_id
    WHERE u.role = 'student' AND u.department = ?
");

$stats_stmt->bind_param("s", $user['department']);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();

// Get performance by month
$monthly_stmt = $conn->prepare("
    SELECT 
        DATE_FORMAT(s.created_at, '%Y-%m') as month,
        COUNT(*) as total_seminars,
        COUNT(CASE WHEN s.evaluation_status = 'evaluated' THEN 1 END) as evaluated_seminars,
        ROUND(AVG(CASE WHEN s.evaluation_status = 'evaluated' THEN 
            (SELECT score FROM seminar_evaluations WHERE seminar_id = s.seminar_id)
        END), 1) as avg_score
    FROM seminars s
    INNER JOIN users u ON s.student_id = u.user_id
    WHERE u.department = ?
    GROUP BY DATE_FORMAT(s.created_at, '%Y-%m')
    ORDER BY month DESC
    LIMIT 6
");

$monthly_stmt->bind_param("s", $user['department']);
$monthly_stmt->execute();
$monthly_stats = $monthly_stmt->get_result();
?>

<div class="container">
    <div class="page-header">
        <h2><i class="fas fa-chart-line"></i> Department Reports</h2>
    </div>

    <?php if ($error_message): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?php echo htmlspecialchars($error_message); ?>
    </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-info">
                <h3>Total Students</h3>
                <p class="stat-value"><?php echo $stats['total_students']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-user-check"></i>
            </div>
            <div class="stat-info">
                <h3>Active Students</h3>
                <p class="stat-value"><?php echo $stats['active_students']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-video"></i>
            </div>
            <div class="stat-info">
                <h3>Total Seminars</h3>
                <p class="stat-value"><?php echo $stats['total_seminars']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-star"></i>
            </div>
            <div class="stat-info">
                <h3>Department Average</h3>
                <p class="stat-value"><?php echo $stats['dept_avg_score'] ?? 'N/A'; ?></p>
            </div>
        </div>
    </div>

    <!-- Monthly Performance -->
    <div class="table-container">
        <div class="table-header">
            <h3>Monthly Performance</h3>
            <form method="post" class="download-form">
                <button type="submit" name="generate_pdf" class="btn-primary">
                    <i class="fas fa-file-pdf"></i> Download Full Report
                </button>
            </form>
        </div>
        
        <?php if ($monthly_stats->num_rows === 0): ?>
        <div class="empty-state">
            <i class="fas fa-chart-bar"></i>
            <h3>No Data Available</h3>
            <p>There are no seminars recorded in your department yet.</p>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Month</th>
                        <th>Total Seminars</th>
                        <th>Evaluated</th>
                        <th>Avg. Score</th>
                        <th>Progress</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($month = $monthly_stats->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo date('F Y', strtotime($month['month'] . '-01')); ?></td>
                        <td class="text-center"><?php echo $month['total_seminars']; ?></td>
                        <td class="text-center"><?php echo $month['evaluated_seminars']; ?></td>
                        <td class="text-center">
                            <?php echo $month['avg_score'] ? number_format($month['avg_score'], 1) : 'N/A'; ?>
                        </td>
                        <td>
                            <div class="progress-bar">
                                <?php 
                                $progress = $month['total_seminars'] > 0 
                                    ? ($month['evaluated_seminars'] / $month['total_seminars']) * 100 
                                    : 0;
                                ?>
                                <div class="progress" style="width: <?php echo $progress; ?>%">
                                    <?php echo round($progress); ?>%
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: white;
    border-radius: 10px;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.stat-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-color);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stat-icon i {
    font-size: 1.5rem;
    color: white;
}

.stat-info h3 {
    font-size: 0.9rem;
    color: #666;
    margin-bottom: 0.25rem;
}

.stat-value {
    font-size: 1.5rem;
    font-weight: 600;
    color: var(--text-color);
    margin: 0;
}

.table-container {
    background: white;
    border-radius: 10px;
    padding: 1.5rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.table-header h3 {
    margin: 0;
    color: var(--text-color);
}

.download-form {
    margin: 0;
}

.table-responsive {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 1rem;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}

th {
    background: var(--light-bg);
    font-weight: 500;
    color: var(--text-color);
}

td {
    color: #666;
}

.text-center {
    text-align: center;
}

.progress-bar {
    width: 100%;
    height: 20px;
    background: #f0f0f0;
    border-radius: 10px;
    overflow: hidden;
}

.progress {
    height: 100%;
    background: var(--primary-color);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 0.8rem;
    transition: width 0.3s ease;
}

.empty-state {
    text-align: center;
    padding: 3rem;
}

.empty-state i {
    font-size: 3rem;
    color: #ccc;
    margin-bottom: 1rem;
}

.empty-state h3 {
    margin: 0 0 0.5rem 0;
    color: var(--text-color);
}

.empty-state p {
    color: #666;
    margin-bottom: 1.5rem;
}

@media (max-width: 768px) {
    .container {
        padding: 1rem;
    }

    .stats-grid {
        grid-template-columns: 1fr 1fr;
    }

    .table-header {
        flex-direction: column;
        gap: 1rem;
    }

    .download-form {
        width: 100%;
    }

    .download-form button {
        width: 100%;
    }
}

.alert {
    padding: 1rem;
    margin-bottom: 1rem;
    border-radius: 5px;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.alert-danger {
    background-color: #fee2e2;
    color: #dc2626;
    border: 1px solid #fecaca;
}
</style>

<script>
// Only add event listener if the search input exists
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchText = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });
        });
    }
});
</script>

<?php
$stats_stmt->close();
$monthly_stmt->close();
$conn->close();
require_once 'includes/footer.php';
ob_end_flush(); // End output buffering
?> 