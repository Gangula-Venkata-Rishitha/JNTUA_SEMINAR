<?php
require_once 'includes/header.php';
require_once '../config/database.php';

$conn = getDBConnection();

// Get all students in the HOD's department
$stmt = $conn->prepare("
    SELECT 
        u.user_id,
        u.username,
        u.full_name,
        u.email,
        u.department,
        COUNT(s.seminar_id) as total_seminars,
        COUNT(CASE WHEN s.evaluation_status = 'evaluated' THEN 1 END) as evaluated_seminars,
        ROUND(AVG(CASE WHEN s.evaluation_status = 'evaluated' THEN 
            (SELECT score FROM seminar_evaluations WHERE seminar_id = s.seminar_id)
        END), 1) as avg_score
    FROM users u
    LEFT JOIN seminars s ON u.user_id = s.student_id
    WHERE u.role = 'student' AND u.department = ?
    GROUP BY u.user_id
    ORDER BY u.full_name
");

$stmt->bind_param("s", $user['department']);
$stmt->execute();
$students = $stmt->get_result();

// Get department statistics
$stats_stmt = $conn->prepare("
    SELECT 
        COUNT(DISTINCT u.user_id) as total_students,
        COUNT(DISTINCT CASE WHEN s.seminar_id IS NOT NULL THEN u.user_id END) as active_students,
        COUNT(s.seminar_id) as total_seminars,
        COUNT(CASE WHEN s.evaluation_status = 'evaluated' THEN 1 END) as evaluated_seminars,
        ROUND(AVG(CASE WHEN s.evaluation_status = 'evaluated' THEN 
            (SELECT score FROM seminar_evaluations WHERE seminar_id = s.seminar_id)
        END), 1) as dept_avg_score
    FROM users u
    LEFT JOIN seminars s ON u.user_id = s.student_id
    WHERE u.role = 'student' AND u.department = ?
");

$stats_stmt->bind_param("s", $user['department']);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();
?>

<div class="container">
    <div class="page-header">
        <h2><i class="fas fa-user-graduate"></i> Student Management</h2>
    </div>

    <!-- Department Statistics -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-info">
                <h3>Total Students</h3>
                <p class="stat-value"><?php echo $stats['total_students']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-user-check"></i>
            </div>
            <div class="stat-info">
                <h3>Active Students</h3>
                <p class="stat-value"><?php echo $stats['active_students']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-video"></i>
            </div>
            <div class="stat-info">
                <h3>Total Seminars</h3>
                <p class="stat-value"><?php echo $stats['total_seminars']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-star"></i>
            </div>
            <div class="stat-info">
                <h3>Department Average</h3>
                <p class="stat-value"><?php echo $stats['dept_avg_score'] ?? 'N/A'; ?></p>
            </div>
        </div>
    </div>

    <!-- Students Table -->
    <div class="table-container">
        <div class="table-header">
            <h3>Students List</h3>
            <div class="table-actions">
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="Search students...">
                    <i class="fas fa-search"></i>
                </div>
            </div>
        </div>
        
        <?php if ($students->num_rows === 0): ?>
        <div class="empty-state">
            <i class="fas fa-users"></i>
            <h3>No Students Found</h3>
            <p>There are no students registered in your department.</p>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Roll Number</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Total Seminars</th>
                        <th>Evaluated</th>
                        <th>Avg. Score</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($student = $students->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($student['username']); ?></td>
                        <td><?php echo htmlspecialchars($student['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($student['email']); ?></td>
                        <td class="text-center"><?php echo $student['total_seminars']; ?></td>
                        <td class="text-center"><?php echo $student['evaluated_seminars']; ?></td>
                        <td class="text-center">
                            <?php echo $student['avg_score'] ? number_format($student['avg_score'], 1) : 'N/A'; ?>
                        </td>
                        <td>
                            <a href="view_seminars.php?student_id=<?php echo $student['user_id']; ?>" 
                               class="btn-icon" title="View Seminars">
                                <i class="fas fa-video"></i>
                            </a>
                            <a href="reports.php?student_id=<?php echo $student['user_id']; ?>" 
                               class="btn-icon" title="Generate Report">
                                <i class="fas fa-file-pdf"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: white;
    border-radius: 10px;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.stat-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-color);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stat-icon i {
    font-size: 1.5rem;
    color: white;
}

.stat-info h3 {
    font-size: 0.9rem;
    color: #666;
    margin-bottom: 0.25rem;
}

.stat-value {
    font-size: 1.5rem;
    font-weight: 600;
    color: var(--text-color);
    margin: 0;
}

.table-container {
    background: white;
    border-radius: 10px;
    padding: 1.5rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.table-header h3 {
    margin: 0;
    color: var(--text-color);
}

.search-box {
    position: relative;
    width: 300px;
}

.search-box input {
    width: 100%;
    padding: 0.5rem 1rem 0.5rem 2.5rem;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    font-size: 0.9rem;
}

.search-box i {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: #666;
}

.table-responsive {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 1rem;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}

th {
    background: var(--light-bg);
    font-weight: 500;
    color: var(--text-color);
}

td {
    color: #666;
}

.text-center {
    text-align: center;
}

.btn-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 5px;
    color: var(--primary-color);
    background: var(--light-bg);
    margin-right: 0.5rem;
    transition: all 0.3s;
}

.btn-icon:hover {
    background: var(--primary-color);
    color: white;
}

.empty-state {
    text-align: center;
    padding: 3rem;
}

.empty-state i {
    font-size: 3rem;
    color: #ccc;
    margin-bottom: 1rem;
}

.empty-state h3 {
    margin: 0 0 0.5rem 0;
    color: var(--text-color);
}

.empty-state p {
    color: #666;
    margin-bottom: 1.5rem;
}

@media (max-width: 768px) {
    .container {
        padding: 1rem;
    }

    .stats-grid {
        grid-template-columns: 1fr 1fr;
    }

    .search-box {
        width: 100%;
        margin-top: 1rem;
    }

    .table-header {
        flex-direction: column;
        align-items: stretch;
    }
}
</style>

<script>
document.getElementById('searchInput').addEventListener('input', function(e) {
    const searchText = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchText) ? '' : 'none';
    });
});
</script>

<?php
$stmt->close();
$stats_stmt->close();
$conn->close();
require_once 'includes/footer.php';
?> 