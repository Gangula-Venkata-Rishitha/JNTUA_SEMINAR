<?php
// Generate password hashes for test users
$passwords = [
    'hod' => 'hod',
    'faculty' => 'faculty',
    '22001a0509' => '22001a0509'
];

echo "-- Insert test users with simple credentials\n";
echo "INSERT INTO users (username, password, full_name, email, role, department) VALUES\n";

// HOD user
$hod_hash = password_hash($passwords['hod'], PASSWORD_DEFAULT);
echo "-- HOD user (username: hod, password: hod)\n";
echo "('hod', '" . $hod_hash . "', 'HOD Test User', 'hod@test.com', 'hod', 'Computer Science'),\n\n";

// Faculty user
$faculty_hash = password_hash($passwords['faculty'], PASSWORD_DEFAULT);
echo "-- Faculty user (username: faculty, password: faculty)\n";
echo "('faculty', '" . $faculty_hash . "', 'Faculty Test User', 'faculty@test.com', 'faculty', 'Computer Science'),\n\n";

// Student user
$student_hash = password_hash($passwords['22001a0509'], PASSWORD_DEFAULT);
echo "-- Student user (username: 22001a0509, password: 22001a0509)\n";
echo "('22001a0509', '" . $student_hash . "', 'Student Test User', 'student@test.com', 'student', 'Computer Science');\n";
?> 