<?php
require_once 'config/database.php';

// HOD data
$hods = [
    [
        'username' => 'hod_cse',
        'full_name' => 'Dr. Rajesh Kumar',
        'email' => 'hod.cse@college.edu',
        'department' => 'CSE',
        'password' => 'CSE@2024'
    ],
    [
        'username' => 'hod_ece',
        'full_name' => 'Dr. Priya Sharma',
        'email' => 'hod.ece@college.edu',
        'department' => 'ECE',
        'password' => 'ECE@2024'
    ],
    [
        'username' => 'hod_eee',
        'full_name' => 'Dr. Suresh Patel',
        'email' => 'hod.eee@college.edu',
        'department' => 'EEE',
        'password' => 'EEE@2024'
    ],
    [
        'username' => 'hod_mech',
        'full_name' => 'Dr. Ramesh Verma',
        'email' => 'hod.mech@college.edu',
        'department' => 'MECH',
        'password' => 'MECH@2024'
    ],
    [
        'username' => 'hod_civil',
        'full_name' => 'Dr. Anita Singh',
        'email' => 'hod.civil@college.edu',
        'department' => 'CIVIL',
        'password' => 'CIVIL@2024'
    ],
    [
        'username' => 'hod_chemical',
        'full_name' => 'Dr. Sanjay Gupta',
        'email' => 'hod.chemical@college.edu',
        'department' => 'CHEMICAL',
        'password' => 'CHEMICAL@2024'
    ]
];

try {
    $conn = getDBConnection();
    
    // Prepare insert statement
    $stmt = $conn->prepare("
        INSERT INTO users (username, full_name, email, password, department, role) 
        VALUES (?, ?, ?, ?, ?, 'hod')
    ");

    $success_count = 0;
    $errors = [];

    foreach ($hods as $hod) {
        // Hash the password
        $hashed_password = password_hash($hod['password'], PASSWORD_DEFAULT);
        
        // Try to insert the HOD
        try {
            $stmt->bind_param("sssss", 
                $hod['username'],
                $hod['full_name'],
                $hod['email'],
                $hashed_password,
                $hod['department']
            );
            
            if ($stmt->execute()) {
                $success_count++;
                echo "<div style='color: green;'>Successfully created HOD account for {$hod['department']}</div>";
                echo "<div style='margin-left: 20px;'>";
                echo "Username: {$hod['username']}<br>";
                echo "Password: {$hod['password']}<br>";
                echo "Department: {$hod['department']}<br>";
                echo "</div><br>";
            }
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) { // Duplicate entry
                $errors[] = "HOD for {$hod['department']} already exists.";
            } else {
                $errors[] = "Error creating HOD for {$hod['department']}: " . $e->getMessage();
            }
        }
    }

    // Display summary
    echo "<h3>Summary:</h3>";
    echo "Successfully created $success_count HOD accounts.<br>";
    
    if (!empty($errors)) {
        echo "<h3>Errors:</h3>";
        foreach ($errors as $error) {
            echo "<div style='color: red;'>$error</div>";
        }
    }

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    echo "<div style='color: red;'>Error: " . $e->getMessage() . "</div>";
}
?>

<style>
    body {
        font-family: Arial, sans-serif;
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        line-height: 1.6;
    }
    div {
        margin-bottom: 10px;
    }
</style> 