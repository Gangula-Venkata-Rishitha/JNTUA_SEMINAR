<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

session_start();
$conn = getDBConnection();

// Print session info
echo "<h3>Session Information:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

// Check seminars table
$query = "SELECT * FROM seminars";
$result = $conn->query($query);

echo "<h3>Seminars Table Contents:</h3>";
if ($result) {
    echo "Total seminars found: " . $result->num_rows . "<br><br>";
    while ($row = $result->fetch_assoc()) {
        echo "<pre>";
        print_r($row);
        echo "</pre>";
    }
} else {
    echo "Error querying seminars table: " . $conn->error;
}

$conn->close();
?> 