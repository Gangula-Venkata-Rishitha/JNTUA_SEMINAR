<?php
require_once 'includes/header.php';
require_once '../config/database.php';

// Check if student ID is provided
if (!isset($_GET['id'])) {
    header('Location: view_students.php');
    exit;
}

$conn = getDBConnection();
$student_id = $_GET['id'];

// Verify the student belongs to the faculty's department
$stmt = $conn->prepare("
    SELECT username, full_name 
    FROM users 
    WHERE user_id = ? AND department = ? AND role = 'student'
");
$stmt->bind_param("is", $student_id, $user['department']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: view_students.php');
    exit;
}

$student = $result->fetch_assoc();

// Generate and set new password
$new_password = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 10);
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
$stmt->bind_param("si", $hashed_password, $student_id);

if ($stmt->execute()) {
    $success_message = "Password reset successful! New password for " . htmlspecialchars($student['full_name']) . " is: " . $new_password;
} else {
    $error_message = "Error resetting password. Please try again.";
}

// Close database connection
$stmt->close();
$conn->close();
?>

<div class="reset-container">
    <?php if (isset($success_message)): ?>
    <div class="alert success">
        <i class="fas fa-check-circle"></i>
        <div class="alert-content">
            <h3>Password Reset Successful</h3>
            <p><?php echo $success_message; ?></p>
            <div class="alert-actions">
                <button class="btn-primary" onclick="window.location.href='view_students.php'">
                    <i class="fas fa-arrow-left"></i>
                    Back to Students
                </button>
            </div>
        </div>
    </div>
    <?php elseif (isset($error_message)): ?>
    <div class="alert error">
        <i class="fas fa-exclamation-circle"></i>
        <div class="alert-content">
            <h3>Error</h3>
            <p><?php echo $error_message; ?></p>
            <div class="alert-actions">
                <button class="btn-primary" onclick="window.location.href='view_students.php'">
                    <i class="fas fa-arrow-left"></i>
                    Back to Students
                </button>
                <button class="btn-secondary" onclick="window.location.reload()">
                    <i class="fas fa-redo"></i>
                    Try Again
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
    .reset-container {
        max-width: 600px;
        margin: 2rem auto;
        padding: 0 1rem;
    }

    .alert {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        padding: 2rem;
        display: flex;
        gap: 1.5rem;
        align-items: flex-start;
    }

    .alert i {
        font-size: 2rem;
    }

    .alert.success {
        border-left: 4px solid #155724;
    }

    .alert.success i {
        color: #155724;
    }

    .alert.error {
        border-left: 4px solid #721c24;
    }

    .alert.error i {
        color: #721c24;
    }

    .alert-content h3 {
        margin-bottom: 0.5rem;
        color: var(--text-color);
    }

    .alert-content p {
        color: #666;
        margin-bottom: 1.5rem;
    }

    .alert-actions {
        display: flex;
        gap: 1rem;
    }

    @media (max-width: 768px) {
        .alert {
            flex-direction: column;
            text-align: center;
        }

        .alert-actions {
            flex-direction: column;
        }

        .alert-actions button {
            width: 100%;
        }
    }
</style>

<?php require_once 'includes/footer.php'; ?> 