<?php
require_once 'includes/header.php';
require_once '../config/database.php';

// Initialize variables
$error = '';
$success = '';
$conn = null;
$stmt = null;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = getDBConnection();
    
    // Get form data
    $username = trim($_POST['username'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $department = $user['department'] ?? '';
    $password_type = $_POST['password_type'] ?? 'auto';
    $custom_password = trim($_POST['custom_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    // Validate inputs
    if (empty($username) || empty($full_name) || empty($email)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif ($password_type === 'custom' && (empty($custom_password) || empty($confirm_password))) {
        $error = "Please enter and confirm the password.";
    } elseif ($password_type === 'custom' && $custom_password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif ($password_type === 'custom' && strlen($custom_password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } else {
        // Check if username or email already exists
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $error = "Username or email already exists.";
        } else {
            // Set password based on type
            if ($password_type === 'auto') {
                // Generate random password
                $password = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*"), 0, 12);
            } else {
                $password = $custom_password;
            }
            
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new student
            $stmt = $conn->prepare("INSERT INTO users (username, full_name, email, password, department, role) VALUES (?, ?, ?, ?, ?, 'student')");
            $stmt->bind_param("sssss", $username, $full_name, $email, $hashed_password, $department);
            
            if ($stmt->execute()) {
                $success = "Student registered successfully!" . ($password_type === 'auto' ? " Initial password: " . $password : "");
                // Clear form data after successful registration
                $username = $full_name = $email = $custom_password = $confirm_password = '';
            } else {
                $error = "Error registering student. Please try again.";
            }
        }
    }
}
?>

<div class="register-container">
    <div class="page-header">
        <div class="header-content">
            <h2><i class="fas fa-user-plus"></i> Register New Student</h2>
            <p>Add a new student to the <?php echo htmlspecialchars($user['department'] ?? 'your'); ?> department</p>
        </div>
    </div>

    <?php if (!empty($error)): ?>
    <div class="alert error">
        <i class="fas fa-exclamation-circle"></i>
        <div class="alert-content">
            <p><?php echo htmlspecialchars($error); ?></p>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
    <div class="alert success">
        <i class="fas fa-check-circle"></i>
        <div class="alert-content">
            <h3>Registration Successful</h3>
            <p><?php echo htmlspecialchars($success); ?></p>
            <?php if (strpos($success, "Initial password:") !== false): ?>
            <div class="alert-note">
                <i class="fas fa-info-circle"></i>
                Please make note of this password as it won't be shown again.
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="form-container">
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username <span class="required">*</span></label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username ?? ''); ?>" required>
                <small>This will be used for login</small>
            </div>

            <div class="form-group">
                <label for="full_name">Full Name <span class="required">*</span></label>
                <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($full_name ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email Address <span class="required">*</span></label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="department">Department</label>
                <input type="text" id="department" name="department" value="<?php echo htmlspecialchars($user['department'] ?? ''); ?>" readonly>
                <small>Students will be registered in your department</small>
            </div>

            <div class="form-group">
                <label>Password Type <span class="required">*</span></label>
                <div class="radio-group">
                    <label class="radio-label">
                        <input type="radio" name="password_type" value="auto" checked onchange="togglePasswordFields()">
                        Auto-generate secure password
                    </label>
                    <label class="radio-label">
                        <input type="radio" name="password_type" value="custom" onchange="togglePasswordFields()">
                        Set custom password
                    </label>
                </div>
            </div>

            <div id="custom-password-fields" style="display: none;">
                <div class="form-group">
                    <label for="custom_password">Password <span class="required">*</span></label>
                    <input type="password" id="custom_password" name="custom_password" minlength="8">
                    <small>Minimum 8 characters</small>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password <span class="required">*</span></label>
                    <input type="password" id="confirm_password" name="confirm_password" minlength="8">
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-primary">
                    <i class="fas fa-user-plus"></i>
                    Register Student
                </button>
                <a href="view_students.php" class="btn-secondary">
                    <i class="fas fa-arrow-left"></i>
                    Back to Students
                </a>
            </div>
        </form>
    </div>
</div>

<style>
    .register-container {
        max-width: 800px;
        margin: 0 auto;
        padding: 2rem;
    }

    .page-header {
        margin-bottom: 2rem;
    }

    .header-content h2 {
        color: var(--text-color);
        margin-bottom: 0.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .header-content p {
        color: #666;
    }

    .form-container {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        padding: 2rem;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    .form-group label {
        display: block;
        margin-bottom: 0.5rem;
        color: var(--text-color);
        font-weight: 500;
    }

    .radio-group {
        display: flex;
        gap: 2rem;
        margin-top: 0.5rem;
    }

    .radio-label {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        cursor: pointer;
    }

    .radio-label input[type="radio"] {
        margin: 0;
    }

    .form-group input {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid var(--border-color);
        border-radius: 5px;
        font-size: 1rem;
    }

    .form-group input:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 2px rgba(var(--primary-rgb), 0.1);
    }

    .form-group input[readonly] {
        background: #f8f9fa;
        cursor: not-allowed;
    }

    .form-group small {
        display: block;
        margin-top: 0.25rem;
        color: #666;
        font-size: 0.875rem;
    }

    .required {
        color: #dc3545;
    }

    .form-actions {
        display: flex;
        gap: 1rem;
        margin-top: 2rem;
    }

    .alert {
        margin-bottom: 2rem;
        padding: 1rem;
        border-radius: 5px;
        display: flex;
        gap: 1rem;
        align-items: flex-start;
    }

    .alert.error {
        background: #f8d7da;
        border: 1px solid #f5c6cb;
        color: #721c24;
    }

    .alert.success {
        background: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
    }

    .alert i {
        font-size: 1.25rem;
    }

    .alert-note {
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid rgba(0,0,0,0.1);
        font-size: 0.875rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    @media (max-width: 768px) {
        .register-container {
            padding: 1rem;
        }

        .radio-group {
            flex-direction: column;
            gap: 1rem;
        }

        .form-actions {
            flex-direction: column;
        }

        .form-actions button,
        .form-actions a {
            width: 100%;
        }
    }
</style>

<script>
function togglePasswordFields() {
    const customFields = document.getElementById('custom-password-fields');
    const passwordType = document.querySelector('input[name="password_type"]:checked').value;
    const customPassword = document.getElementById('custom_password');
    const confirmPassword = document.getElementById('confirm_password');
    
    if (passwordType === 'custom') {
        customFields.style.display = 'block';
        customPassword.required = true;
        confirmPassword.required = true;
    } else {
        customFields.style.display = 'none';
        customPassword.required = false;
        confirmPassword.required = false;
        customPassword.value = '';
        confirmPassword.value = '';
    }
}
</script>

<?php
if ($conn) {
    if ($stmt) $stmt->close();
    $conn->close();
}
require_once 'includes/footer.php';
?> 