<?php
require_once 'includes/header.php';
require_once '../config/database.php';

$conn = getDBConnection();

// Get all students in the faculty's department
$stmt = $conn->prepare("
    SELECT 
        u.user_id,
        u.username,
        u.full_name,
        u.email,
        u.created_at,
        (SELECT COUNT(*) FROM seminars s WHERE s.student_id = u.user_id) as total_seminars,
        (SELECT COUNT(*) FROM seminars s WHERE s.student_id = u.user_id AND s.evaluation_status = 'pending') as pending_seminars
    FROM users u 
    WHERE u.department = ? AND u.role = 'student'
    ORDER BY u.full_name ASC
");

$stmt->bind_param("s", $user['department']);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="students-container">
    <div class="page-header">
        <div class="header-content">
            <h2><i class="fas fa-user-graduate"></i> My Students</h2>
            <p>Manage students in the <?php echo htmlspecialchars($user['department']); ?> department</p>
        </div>
        <a href="register_student.php" class="btn-primary">
            <i class="fas fa-user-plus"></i>
            Register New Student
        </a>
    </div>

    <?php if ($result->num_rows === 0): ?>
    <div class="empty-state">
        <i class="fas fa-users-slash"></i>
        <h3>No Students Found</h3>
        <p>There are no students registered in your department yet.</p>
        <a href="register_student.php" class="btn-primary">Register New Student</a>
    </div>
    <?php else: ?>
    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Total Seminars</th>
                    <th>Pending Evaluations</th>
                    <th>Registered On</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($student = $result->fetch_assoc()): ?>
                <tr>
                    <td>
                        <div class="student-name">
                            <i class="fas fa-user-circle"></i>
                            <?php echo htmlspecialchars($student['full_name']); ?>
                        </div>
                    </td>
                    <td><?php echo htmlspecialchars($student['username']); ?></td>
                    <td>
                        <a href="mailto:<?php echo htmlspecialchars($student['email']); ?>" class="email-link">
                            <?php echo htmlspecialchars($student['email']); ?>
                        </a>
                    </td>
                    <td class="text-center"><?php echo $student['total_seminars']; ?></td>
                    <td class="text-center">
                        <?php if ($student['pending_seminars'] > 0): ?>
                        <span class="badge warning">
                            <?php echo $student['pending_seminars']; ?> Pending
                        </span>
                        <?php else: ?>
                        <span class="badge success">All Evaluated</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo date('M d, Y', strtotime($student['created_at'])); ?></td>
                    <td>
                        <div class="action-buttons">
                           
                            <a href="reset_password.php?id=<?php echo $student['user_id']; ?>" 
                               class="btn-icon warning" title="Reset Password"
                               onclick="return confirm('Are you sure you want to reset the password for this student?');">
                                <i class="fas fa-key"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<style>
    .students-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem;
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
    }

    .header-content h2 {
        color: var(--text-color);
        margin-bottom: 0.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .header-content p {
        color: #666;
    }

    .empty-state {
        text-align: center;
        padding: 3rem;
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .empty-state i {
        font-size: 3rem;
        color: var(--primary-color);
        margin-bottom: 1rem;
    }

    .empty-state h3 {
        margin-bottom: 0.5rem;
        color: var(--text-color);
    }

    .empty-state p {
        color: #666;
        margin-bottom: 1.5rem;
    }

    .table-container {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        overflow: hidden;
    }

    .data-table {
        width: 100%;
        border-collapse: collapse;
    }

    .data-table th,
    .data-table td {
        padding: 1rem;
        text-align: left;
        border-bottom: 1px solid var(--border-color);
    }

    .data-table th {
        background: #f8f9fa;
        font-weight: 600;
        color: var(--text-color);
    }

    .data-table tr:last-child td {
        border-bottom: none;
    }

    .student-name {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: var(--text-color);
        font-weight: 500;
    }

    .student-name i {
        color: var(--primary-color);
    }

    .email-link {
        color: var(--primary-color);
        text-decoration: none;
    }

    .email-link:hover {
        text-decoration: underline;
    }

    .text-center {
        text-align: center;
    }

    .badge {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        border-radius: 15px;
        font-size: 0.85rem;
        font-weight: 500;
    }

    .badge.warning {
        background: #fff3cd;
        color: #856404;
    }

    .badge.success {
        background: #d4edda;
        color: #155724;
    }

    .action-buttons {
        display: flex;
        gap: 0.5rem;
    }

    .btn-icon {
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 5px;
        color: var(--primary-color);
        background: var(--light-bg);
        text-decoration: none;
        transition: all 0.3s;
    }

    .btn-icon:hover {
        background: var(--primary-color);
        color: white;
    }

    .btn-icon.warning {
        color: #856404;
        background: #fff3cd;
    }

    .btn-icon.warning:hover {
        background: #856404;
        color: white;
    }

    @media (max-width: 1024px) {
        .data-table {
            display: block;
            overflow-x: auto;
            white-space: nowrap;
        }
    }

    @media (max-width: 768px) {
        .students-container {
            padding: 1rem;
        }

        .page-header {
            flex-direction: column;
            gap: 1rem;
            text-align: center;
        }

        .header-content {
            text-align: center;
        }

        .header-content h2 {
            justify-content: center;
        }
    }
</style>

<?php
$stmt->close();
$conn->close();
require_once 'includes/footer.php';
?> 