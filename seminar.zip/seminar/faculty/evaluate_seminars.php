<?php
// Handle evaluation submission via AJAX first, before any output
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'evaluate') {
    // Set JSON header
    header('Content-Type: application/json');
    
    try {
        if (!isset($_POST['seminar_id']) || !isset($_POST['score']) || !isset($_POST['remarks'])) {
            throw new Exception('Missing required fields');
        }
        
        $seminar_id = intval($_POST['seminar_id']);
        $score = floatval($_POST['score']);
        $remarks = trim($_POST['remarks']);
        
        // Validate input
        if ($score < 0 || $score > 10) {
            throw new Exception('Score must be between 0 and 10');
        }
        
        if (empty($remarks)) {
            throw new Exception('Remarks are required');
        }

        require_once '../config/database.php';
        $conn = getDBConnection();
        
        // Begin transaction
        $conn->begin_transaction();
        
        // Check if evaluation exists
        $check_stmt = $conn->prepare("SELECT evaluation_id FROM seminar_evaluations WHERE seminar_id = ?");
        $check_stmt->bind_param("i", $seminar_id);
        $check_stmt->execute();
        $existing = $check_stmt->get_result()->fetch_assoc();
        
        if ($existing) {
            // Update existing evaluation
            $update_stmt = $conn->prepare("
                UPDATE seminar_evaluations 
                SET score = ?, remarks = ?, evaluation_date = NOW() 
                WHERE seminar_id = ?
            ");
            $update_stmt->bind_param("dsi", $score, $remarks, $seminar_id);
            $update_stmt->execute();
        } else {
            // Insert new evaluation
            $insert_stmt = $conn->prepare("
                INSERT INTO seminar_evaluations (seminar_id, faculty_id, score, remarks, evaluation_date)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $insert_stmt->bind_param("iids", $seminar_id, $user['user_id'], $score, $remarks);
            $insert_stmt->execute();
        }
        
        // Update seminar status
        $status_stmt = $conn->prepare("UPDATE seminars SET evaluation_status = 'evaluated' WHERE seminar_id = ?");
        $status_stmt->bind_param("i", $seminar_id);
        $status_stmt->execute();
        
        $conn->commit();
        echo json_encode([
            'success' => true,
            'message' => 'Evaluation submitted successfully'
        ]);
    } catch (Exception $e) {
        if (isset($conn)) {
            $conn->rollback();
        }
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

// Regular page load
require_once 'includes/header.php';
require_once '../config/database.php';

$conn = getDBConnection();
$success_message = '';
$error_message = '';

// Get pending seminars
$pending_stmt = $conn->prepare("
    SELECT s.*, u.full_name as student_name, u.username as roll_number
    FROM seminars s
    INNER JOIN users u ON s.student_id = u.user_id
    WHERE s.evaluation_status = 'pending'
    ORDER BY s.created_at DESC
");
$pending_stmt->execute();
$pending_seminars = $pending_stmt->get_result();

// Get evaluated seminars
$evaluated_stmt = $conn->prepare("
    SELECT s.*, u.full_name as student_name, u.username as roll_number,
           se.evaluation_id, se.score, se.remarks, se.evaluation_date,
           f.full_name as evaluator_name
    FROM seminars s
    INNER JOIN users u ON s.student_id = u.user_id
    INNER JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id
    LEFT JOIN users f ON se.faculty_id = f.user_id
    WHERE s.evaluation_status = 'evaluated'
    ORDER BY se.evaluation_date DESC
");
$evaluated_stmt->execute();
$evaluated_seminars = $evaluated_stmt->get_result();
?>

<div class="seminars-container">
    <div class="page-header">
        <h2><i class="fas fa-chalkboard-teacher"></i> Evaluate Seminars</h2>
    </div>

    <!-- Tabs -->
    <div class="tabs">
        <button class="tab-btn active" onclick="showTab('pending')">
            <i class="fas fa-clock"></i> Pending 
            <span class="count"><?php echo $pending_seminars->num_rows; ?></span>
        </button>
        <button class="tab-btn" onclick="showTab('evaluated')">
            <i class="fas fa-check-circle"></i> Evaluated 
            <span class="count"><?php echo $evaluated_seminars->num_rows; ?></span>
        </button>
    </div>

    <!-- Pending Seminars Section -->
    <div id="pending-section" class="tab-content active">
        <?php if ($pending_seminars->num_rows === 0): ?>
        <div class="empty-state">
            <i class="fas fa-clipboard-check"></i>
            <h3>No Pending Seminars</h3>
            <p>There are no seminars waiting for evaluation.</p>
        </div>
        <?php else: ?>
        <div class="seminars-grid">
            <?php while ($seminar = $pending_seminars->fetch_assoc()): ?>
            <div class="seminar-card">
                <a href="<?php echo htmlspecialchars($seminar['video_url']); ?>" target="_blank" class="video-container">
                    <img src="../uploads/thumbnails/<?php echo htmlspecialchars($seminar['thumbnail_url']); ?>" 
                         alt="<?php echo htmlspecialchars($seminar['title']); ?> thumbnail"
                         class="seminar-thumbnail">
                    <div class="play-overlay">
                        <i class="fas fa-play-circle"></i>
                    </div>
                </a>
                <div class="seminar-info">
                    <h3><?php echo htmlspecialchars($seminar['title']); ?></h3>
                    <p class="description"><?php echo htmlspecialchars($seminar['description']); ?></p>
                    <div class="meta-info">
                        <span class="student-info">
                            <i class="fas fa-user-graduate"></i>
                            <?php echo htmlspecialchars($seminar['student_name']); ?> 
                            (<?php echo htmlspecialchars($seminar['roll_number']); ?>)
                        </span>
                        <span class="date">
                            <i class="fas fa-calendar"></i>
                            <?php echo date('M d, Y', strtotime($seminar['created_at'])); ?>
                        </span>
                    </div>
                    <button class="btn-primary evaluate-btn" 
                            onclick="openEvaluationModal(<?php echo $seminar['seminar_id']; ?>)">
                        <i class="fas fa-star"></i> Evaluate
                    </button>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Evaluated Seminars Section -->
    <div id="evaluated-section" class="tab-content">
        <?php if ($evaluated_seminars->num_rows === 0): ?>
        <div class="empty-state">
            <i class="fas fa-tasks"></i>
            <h3>No Evaluated Seminars</h3>
            <p>You haven't evaluated any seminars yet.</p>
        </div>
        <?php else: ?>
        <div class="seminars-grid">
            <?php while ($seminar = $evaluated_seminars->fetch_assoc()): ?>
            <div class="seminar-card evaluated">
                <a href="<?php echo htmlspecialchars($seminar['video_url']); ?>" target="_blank" class="video-container">
                    <img src="../uploads/thumbnails/<?php echo htmlspecialchars($seminar['thumbnail_url']); ?>" 
                         alt="<?php echo htmlspecialchars($seminar['title']); ?> thumbnail"
                         class="seminar-thumbnail">
                    <div class="play-overlay">
                        <i class="fas fa-play-circle"></i>
                    </div>
                </a>
                <div class="seminar-info">
                    <h3><?php echo htmlspecialchars($seminar['title']); ?></h3>
                    <p class="description"><?php echo htmlspecialchars($seminar['description']); ?></p>
                    <div class="meta-info">
                        <span class="student-info">
                            <i class="fas fa-user-graduate"></i>
                            <?php echo htmlspecialchars($seminar['student_name']); ?> 
                            (<?php echo htmlspecialchars($seminar['roll_number']); ?>)
                        </span>
                        <span class="date">
                            <i class="fas fa-calendar"></i>
                            <?php echo date('M d, Y', strtotime($seminar['evaluation_date'])); ?>
                        </span>
                    </div>
                    <div class="evaluation-details">
                        <div class="score">
                            <span class="label">Score:</span>
                            <span class="value"><?php echo number_format($seminar['score'], 1); ?>/10</span>
                        </div>
                        <div class="evaluator">
                            <span class="label">Evaluated by:</span>
                            <span class="value"><?php echo htmlspecialchars($seminar['evaluator_name']); ?></span>
                        </div>
                        <?php if ($seminar['remarks']): ?>
                        <div class="remarks">
                            <span class="label">Remarks:</span>
                            <p><?php echo nl2br(htmlspecialchars($seminar['remarks'])); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Evaluation Modal -->
<div id="evaluationModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Evaluate Seminar</h3>
            <button type="button" class="close-btn" onclick="closeEvaluationModal()">×</button>
        </div>
        <form id="evaluationForm">
            <input type="hidden" name="seminar_id" id="seminar_id">
            <div class="form-group">
                <label for="score">Score (0-10)</label>
                <div class="score-input">
                    <div class="score-display">
                        Score: <span id="scoreDisplay">7</span>/10
                    </div>
                    <input type="number" id="score" name="score" min="0" max="10" step="0.5" value="7" required>
                    <div class="score-controls">
                        <button type="button" onclick="adjustScore(0.5)">+</button>
                        <button type="button" onclick="adjustScore(-0.5)">−</button>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="remarks">Remarks</label>
                <textarea id="remarks" name="remarks" rows="4" required></textarea>
            </div>
            <div class="form-actions">
                <button type="button" class="btn-secondary" onclick="closeEvaluationModal()">Cancel</button>
                <button type="submit" class="btn-primary">Submit Evaluation</button>
            </div>
        </form>
    </div>
</div>

<style>
    .tabs {
        display: flex;
        gap: 1rem;
        margin-bottom: 2rem;
        border-bottom: 1px solid var(--border-color);
        padding-bottom: 1rem;
    }

    .tab-btn {
        background: none;
        border: none;
        padding: 0.5rem 1rem;
        font-size: 1rem;
        color: #666;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        position: relative;
    }

    .tab-btn:hover {
        color: var(--primary-color);
    }

    .tab-btn.active {
        color: var(--primary-color);
        font-weight: 500;
    }

    .tab-btn.active::after {
        content: '';
        position: absolute;
        bottom: -1rem;
        left: 0;
        width: 100%;
        height: 2px;
        background: var(--primary-color);
    }

    .count {
        background: #eee;
        padding: 0.2rem 0.5rem;
        border-radius: 12px;
        font-size: 0.8rem;
        color: #666;
    }

    .tab-content {
        display: none;
    }

    .tab-content.active {
        display: block;
    }

    .seminar-card.evaluated {
        border-left: 4px solid var(--primary-color);
    }

    .evaluation-details {
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid var(--border-color);
    }

    .evaluation-details > div {
        margin-bottom: 0.5rem;
    }

    .evaluation-details .label {
        color: #666;
        font-size: 0.9rem;
        margin-right: 0.5rem;
    }

    .evaluation-details .value {
        color: var(--text-color);
        font-weight: 500;
    }

    .evaluation-details .score .value {
        color: var(--primary-color);
    }

    @media (max-width: 768px) {
        .tabs {
            flex-direction: row;
            overflow-x: auto;
            padding-bottom: 0.5rem;
        }

        .tab-btn.active::after {
            bottom: -0.5rem;
        }
    }

    /* Modal Styles */
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 1000;
        overflow-y: auto;
    }

    .modal-content {
        background: white;
        width: 90%;
        max-width: 500px;
        margin: 2rem auto;
        border-radius: 10px;
        box-shadow: 0 3px 15px rgba(0, 0, 0, 0.2);
    }

    .modal-header {
        padding: 1.5rem;
        border-bottom: 1px solid var(--border-color);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .modal-header h3 {
        margin: 0;
        color: var(--text-color);
    }

    .close-btn {
        background: none;
        border: none;
        font-size: 1.5rem;
        color: #666;
        cursor: pointer;
        padding: 0;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: background-color 0.3s;
    }

    .close-btn:hover {
        background: #f0f0f0;
    }

    #evaluationForm {
        padding: 1.5rem;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    .form-group label {
        display: block;
        margin-bottom: 0.5rem;
        color: var(--text-color);
        font-weight: 500;
    }

    .score-display {
        background: #f5f5f5;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        text-align: center;
        font-weight: 500;
        color: var(--primary-color);
        margin-bottom: 0.5rem;
    }

    .score-input {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .score-controls {
        display: flex;
        gap: 0.5rem;
        justify-content: center;
    }

    .score-controls button {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    textarea {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid var(--border-color);
        border-radius: 5px;
        resize: vertical;
        min-height: 100px;
        font-family: inherit;
    }

    textarea:focus {
        outline: none;
        border-color: var(--primary-color);
    }

    .form-actions {
        display: flex;
        justify-content: flex-end;
        gap: 1rem;
        margin-top: 2rem;
    }

    .btn-secondary {
        background: #f0f0f0;
        color: #666;
        border: none;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        cursor: pointer;
        font-size: 0.9rem;
        transition: background 0.3s;
    }

    .btn-secondary:hover {
        background: #e0e0e0;
    }

    @media (max-width: 768px) {
        .modal-content {
            margin: 1rem;
            width: auto;
        }
    }

    /* Toast notifications */
    .toast {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 4px;
        color: white;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        transform: translateX(120%);
        transition: transform 0.3s ease-in-out;
        z-index: 1000;
    }

    .toast.show {
        transform: translateX(0);
    }

    .toast-success {
        background-color: #4caf50;
    }

    .toast-error {
        background-color: #f44336;
    }

    .toast i {
        font-size: 1.2rem;
    }
</style>

<script>
function showTab(tabId) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });

    // Remove active class from all tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // Show selected tab content
    document.getElementById(tabId + '-section').classList.add('active');
    
    // Add active class to clicked button
    event.currentTarget.classList.add('active');
}

function openEvaluationModal(seminarId) {
    const modal = document.getElementById('evaluationModal');
    const form = document.getElementById('evaluationForm');
    form.elements.seminar_id.value = seminarId;
    modal.style.display = 'block';
    
    // Reset form and set default score
    form.reset();
    form.elements.score.value = '7';
    updateScoreDisplay();
}

function closeEvaluationModal() {
    const modal = document.getElementById('evaluationModal');
    modal.style.display = 'none';
}

function adjustScore(amount) {
    const scoreInput = document.getElementById('score');
    let newScore = parseFloat(scoreInput.value) + amount;
    newScore = Math.min(Math.max(newScore, 0), 10);
    scoreInput.value = newScore.toFixed(1);
    updateScoreDisplay();
}

function updateScoreDisplay() {
    const score = document.getElementById('score').value;
    const display = document.getElementById('scoreDisplay');
    if (display) {
        display.textContent = score;
    }
}

// Update score display when input changes directly
document.getElementById('score').addEventListener('input', updateScoreDisplay);

document.getElementById('evaluationForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const submitButton = this.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
    
    const formData = new FormData(this);
    formData.append('action', 'evaluate');
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            showToast('success', data.message);
            closeEvaluationModal();
            // Reload the page to update the seminar lists
            window.location.reload();
        } else {
            showToast('error', data.message);
        }
    })
    .catch(error => {
        showToast('error', 'An error occurred while submitting the evaluation');
        console.error('Error:', error);
    })
    .finally(() => {
        submitButton.disabled = false;
        submitButton.innerHTML = originalText;
    });
});

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('evaluationModal');
    if (event.target === modal) {
        closeEvaluationModal();
    }
}

function showToast(type, message) {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    document.body.appendChild(toast);
    
    // Trigger reflow to enable animation
    toast.offsetHeight;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
</script>

<?php
$pending_stmt->close();
$evaluated_stmt->close();
$conn->close();
require_once 'includes/footer.php';
?> 