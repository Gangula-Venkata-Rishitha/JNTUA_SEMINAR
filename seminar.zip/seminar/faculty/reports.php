<?php
ob_start(); // Start output buffering
require_once 'includes/header.php';
require_once '../config/database.php';
require_once '../vendor/autoload.php';

$conn = getDBConnection();
$success_message = '';
$error_message = '';

// Get department statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(DISTINCT s.student_id) as total_students,
        COUNT(s.seminar_id) as total_seminars,
        COUNT(CASE WHEN s.evaluation_status = 'evaluated' THEN 1 END) as evaluated_seminars,
        ROUND(AVG(CASE WHEN s.evaluation_status = 'evaluated' THEN se.score END), 2) as avg_score
    FROM seminars s
    LEFT JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id
    INNER JOIN users u ON s.student_id = u.user_id
    WHERE u.department = ?
");
$stmt->bind_param("s", $user['department']);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();

// Get student performance data
$students_stmt = $conn->prepare("
    SELECT 
        u.user_id,
        u.full_name,
        u.username as roll_number,
        COUNT(s.seminar_id) as total_seminars,
        COUNT(CASE WHEN s.evaluation_status = 'evaluated' THEN 1 END) as evaluated_seminars,
        ROUND(AVG(CASE WHEN s.evaluation_status = 'evaluated' THEN se.score END), 2) as avg_score
    FROM users u
    LEFT JOIN seminars s ON u.user_id = s.student_id
    LEFT JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id
    WHERE u.department = ? AND u.role = 'student'
    GROUP BY u.user_id
    ORDER BY u.full_name
");
$students_stmt->bind_param("s", $user['department']);
$students_stmt->execute();
$students = $students_stmt->get_result();

// Generate PDF Report
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_pdf'])) {
    // Clear any output that might have been sent
    ob_clean();
    
    // Create new PDF document with full namespace reference
    $pdf = new \TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

    // Set document information
    $pdf->SetCreator('Seminar Management System');
    $pdf->SetAuthor($user['full_name']);
    $pdf->SetTitle('Student Performance Report - ' . $user['department'] . ' Department');

    // Remove default header/footer
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // Set default monospaced font
    $pdf->SetDefaultMonospacedFont('courier');

    // Set margins
    $pdf->SetMargins(15, 15, 15);

    // Set auto page breaks
    $pdf->SetAutoPageBreak(true, 15);

    // Add a page
    $pdf->AddPage();

    // Set font for title
    $pdf->SetFont('helvetica', 'B', 20);
    
    // Add title
    $pdf->Cell(0, 10, 'Student Performance Report', 0, 1, 'C');
    $pdf->Cell(0, 10, $user['department'] . ' Department', 0, 1, 'C');
    $pdf->Ln(10);

    // Department Statistics
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'Department Statistics', 0, 1, 'L');
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Ln(5);

    $stats_html = '
    <table border="0" cellpadding="5">
        <tr>
            <td width="200">Total Students:</td>
            <td>' . $stats['total_students'] . '</td>
        </tr>
        <tr>
            <td>Total Seminars:</td>
            <td>' . $stats['total_seminars'] . '</td>
        </tr>
        <tr>
            <td>Evaluated Seminars:</td>
            <td>' . $stats['evaluated_seminars'] . '</td>
        </tr>
        <tr>
            <td>Average Score:</td>
            <td>' . ($stats['avg_score'] ?? 'N/A') . '</td>
        </tr>
    </table>';
    
    $pdf->writeHTML($stats_html, true, false, true, false, '');
    $pdf->Ln(10);

    // Student Performance Table
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'Student Performance', 0, 1, 'L');
    $pdf->Ln(5);

    $table_html = '
    <table border="1" cellpadding="5">
        <thead>
            <tr style="background-color: #f5f5f5;">
                <th width="40">#</th>
                <th width="180">Student Name</th>
                <th width="100">Roll Number</th>
                <th width="100">Total Seminars</th>
                <th width="100">Evaluated</th>
                <th width="100">Avg. Score</th>
            </tr>
        </thead>
        <tbody>';

    $students->data_seek(0);
    $i = 1;
    while ($student = $students->fetch_assoc()) {
        $table_html .= '
        <tr>
            <td>' . $i++ . '</td>
            <td>' . htmlspecialchars($student['full_name']) . '</td>
            <td>' . htmlspecialchars($student['roll_number']) . '</td>
            <td align="center">' . $student['total_seminars'] . '</td>
            <td align="center">' . $student['evaluated_seminars'] . '</td>
            <td align="center">' . ($student['avg_score'] ?? 'N/A') . '</td>
        </tr>';
    }

    $table_html .= '
        </tbody>
    </table>';

    $pdf->writeHTML($table_html, true, false, true, false, '');

    // Output the PDF
    $pdf->Output('student_performance_report.pdf', 'D');
    exit;
}

// Rest of the HTML content
?>

<div class="reports-container">
    <div class="page-header">
        <h2><i class="fas fa-chart-bar"></i> Performance Reports</h2>
    </div>

    <!-- Department Statistics -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-user-graduate"></i>
            </div>
            <div class="stat-info">
                <h3>Total Students</h3>
                <p class="stat-value"><?php echo $stats['total_students']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-video"></i>
            </div>
            <div class="stat-info">
                <h3>Total Seminars</h3>
                <p class="stat-value"><?php echo $stats['total_seminars']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-info">
                <h3>Evaluated Seminars</h3>
                <p class="stat-value"><?php echo $stats['evaluated_seminars']; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-star"></i>
            </div>
            <div class="stat-info">
                <h3>Average Score</h3>
                <p class="stat-value"><?php echo number_format($stats['avg_score'] ?? 0, 2); ?></p>
            </div>
        </div>
    </div>

    <!-- Student Performance Table -->
    <div class="table-container">
        <div class="table-header">
            <h3>Student Performance</h3>
            <form method="post" class="download-form">
                <button type="submit" name="generate_pdf" class="btn-primary">
                    <i class="fas fa-file-pdf"></i> Download PDF Report
                </button>
            </form>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student Name</th>
                        <th>Roll Number</th>
                        <th>Total Seminars</th>
                        <th>Evaluated</th>
                        <th>Avg. Score</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $students->data_seek(0);
                    $i = 1;
                    while ($student = $students->fetch_assoc()): 
                    ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo htmlspecialchars($student['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($student['roll_number']); ?></td>
                        <td class="text-center"><?php echo $student['total_seminars']; ?></td>
                        <td class="text-center"><?php echo $student['evaluated_seminars']; ?></td>
                        <td class="text-center">
                            <?php echo $student['avg_score'] ? number_format($student['avg_score'], 2) : 'N/A'; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
    .reports-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .stat-card {
        background: white;
        border-radius: 10px;
        padding: 1.5rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .stat-icon {
        width: 50px;
        height: 50px;
        background: var(--primary-color);
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .stat-icon i {
        font-size: 1.5rem;
        color: white;
    }

    .stat-info h3 {
        font-size: 0.9rem;
        color: #666;
        margin-bottom: 0.25rem;
    }

    .stat-value {
        font-size: 1.5rem;
        font-weight: 600;
        color: var(--text-color);
        margin: 0;
    }

    .table-container {
        background: white;
        border-radius: 10px;
        padding: 1.5rem;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
    }

    .table-header h3 {
        margin: 0;
        color: var(--text-color);
    }

    .table-responsive {
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        padding: 1rem;
        text-align: left;
        border-bottom: 1px solid var(--border-color);
    }

    th {
        background: var(--light-bg);
        font-weight: 500;
        color: var(--text-color);
    }

    td {
        color: #666;
    }

    .text-center {
        text-align: center;
    }

    .download-form {
        margin: 0;
    }

    @media (max-width: 768px) {
        .reports-container {
            padding: 1rem;
        }

        .stats-grid {
            grid-template-columns: 1fr;
        }

        .table-header {
            flex-direction: column;
            gap: 1rem;
        }

        th, td {
            padding: 0.75rem;
        }
    }
</style>

<?php
$stmt->close();
$students_stmt->close();
$conn->close();
require_once 'includes/footer.php';
?> 