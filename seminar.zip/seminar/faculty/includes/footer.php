        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <script>
        // Mobile sidebar toggle
        document.querySelector('.menu-toggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(e) {
            const sidebar = document.querySelector('.sidebar');
            const menuToggle = document.querySelector('.menu-toggle');
            
            if (window.innerWidth <= 768 && 
                !sidebar.contains(e.target) && 
                !menuToggle.contains(e.target) && 
                sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        });

        // Search functionality
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const rows = document.querySelectorAll('tbody tr');
                
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(searchTerm) ? '' : 'none';
                });
            });
        }

        // Filter functionality
        const filterSelect = document.querySelector('.filter-select');
        if (filterSelect) {
            filterSelect.addEventListener('change', function() {
                const filterValue = this.value.toLowerCase();
                const rows = document.querySelectorAll('tbody tr');
                
                rows.forEach(row => {
                    if (filterValue === '' || row.dataset.status === filterValue) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
        }

        // PDF Generation Helper
        function generatePDF(title, headers, data) {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            // Add title
            doc.setFontSize(18);
            doc.text(title, 20, 20);
            
            // Add table
            doc.autoTable({
                head: [headers],
                body: data,
                startY: 30,
                styles: { fontSize: 10 },
                headStyles: { fillColor: [74, 144, 226] }
            });
            
            // Save PDF
            doc.save(title.toLowerCase().replace(/\s+/g, '-') + '.pdf');
        }

        // Video Player Helper
        function initializeVideoPlayer(videoId) {
            const player = document.getElementById(videoId);
            if (player) {
                player.addEventListener('play', function() {
                    // Log video start time for evaluation purposes
                    console.log('Video started at:', new Date().toISOString());
                });

                player.addEventListener('pause', function() {
                    // Log video pause time for evaluation purposes
                    console.log('Video paused at:', new Date().toISOString());
                });

                player.addEventListener('ended', function() {
                    // Log video completion for evaluation purposes
                    console.log('Video completed at:', new Date().toISOString());
                });
            }
        }
    </script>
</body>
</html> 