<?php
require_once 'includes/header.php';
require_once '../config/database.php';
require_once '../includes/pdf_generator.php';

$conn = getDBConnection();

// Handle report generation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'];
    
    // Get student details
    $stmt = $conn->prepare("
        SELECT u.*, 
               COUNT(s.seminar_id) as total_seminars,
               COUNT(CASE WHEN s.evaluation_status = 'evaluated' THEN 1 END) as evaluated_seminars,
               AVG(se.score) as avg_score
        FROM users u
        LEFT JOIN seminars s ON u.user_id = s.student_id
        LEFT JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id
        WHERE u.user_id = ? AND u.role = 'student'
        GROUP BY u.user_id
    ");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $student = $stmt->get_result()->fetch_assoc();
    
    if ($student) {
        $pdf = new SeminarReportPDF('P', 'mm', 'A4', true, 'UTF-8', false);
        
        // Set document information
        $pdf->SetCreator('SeminarHub');
        $pdf->SetAuthor($user['full_name']);
        $pdf->SetTitle('Student Evaluation Report');
        
        // Set margins
        $pdf->SetMargins(10, 20, 10);
        $pdf->SetAutoPageBreak(TRUE, 15);
        
        // Add a page
        $pdf->AddPage();
        
        // Add student information
        $pdf->InfoSection('Student Information', [
            'Name' => $student['full_name'],
            'Roll Number' => $student['username'],
            'Department' => $student['department'],
            'Total Seminars' => $student['total_seminars'],
            'Evaluated Seminars' => $student['evaluated_seminars'],
            'Average Score' => number_format($student['avg_score'] ?? 0, 2) . '/10'
        ]);
        
        // Get seminar evaluations
        $stmt = $conn->prepare("
            SELECT s.*, se.score, se.remarks, se.evaluation_date,
                   f.full_name as faculty_name
            FROM seminars s
            LEFT JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id
            LEFT JOIN users f ON se.faculty_id = f.user_id
            WHERE s.student_id = ?
            ORDER BY s.upload_date DESC
        ");
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
        $seminars = $stmt->get_result();
        
        // Add seminar details
        $pdf->SectionTitle('Seminar Evaluations');
        
        while ($seminar = $seminars->fetch_assoc()) {
            $pdf->InfoSection('Seminar: ' . $seminar['title'], [
                'Upload Date' => date('F j, Y', strtotime($seminar['upload_date'])),
                'Status' => ucfirst($seminar['evaluation_status'])
            ]);
            
            if ($seminar['evaluation_status'] === 'evaluated') {
                $pdf->EvaluationDetails([
                    'score' => $seminar['score'],
                    'faculty_name' => $seminar['faculty_name'],
                    'evaluation_date' => $seminar['evaluation_date'],
                    'remarks' => $seminar['remarks']
                ]);
            }
        }
        
        // Output PDF
        $pdf->Output('student_evaluation_report.pdf', 'D');
        exit;
    }
}

// Get all students
$stmt = $conn->prepare("
    SELECT u.user_id, u.full_name, u.username, u.department,
           COUNT(s.seminar_id) as seminars_count,
           AVG(se.score) as avg_score
    FROM users u
    LEFT JOIN seminars s ON u.user_id = s.student_id
    LEFT JOIN seminar_evaluations se ON s.seminar_id = se.seminar_id
    WHERE u.role = 'student'
    GROUP BY u.user_id
    ORDER BY u.full_name
");
$stmt->execute();
$students = $stmt->get_result();
?>

<div class="report-container">
    <div class="page-header animate-fade-in">
        <h2><i class="fas fa-file-pdf"></i> Student Evaluation Reports</h2>
        <p>Generate detailed evaluation reports for your students</p>
    </div>

    <div class="students-grid animate-slide-up">
        <?php while ($student = $students->fetch_assoc()): ?>
            <div class="student-card">
                <div class="student-info">
                    <h3><?php echo htmlspecialchars($student['full_name']); ?></h3>
                    <p class="roll-number"><?php echo htmlspecialchars($student['username']); ?></p>
                    <p class="department"><?php echo htmlspecialchars($student['department']); ?></p>
                    
                    <div class="stats">
                        <div class="stat">
                            <span class="label">Seminars</span>
                            <span class="value"><?php echo $student['seminars_count']; ?></span>
                        </div>
                        <div class="stat">
                            <span class="label">Avg Score</span>
                            <span class="value"><?php echo number_format($student['avg_score'] ?? 0, 2); ?></span>
                        </div>
                    </div>
                </div>
                
                <form method="POST" class="report-action">
                    <input type="hidden" name="student_id" value="<?php echo $student['user_id']; ?>">
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-download"></i> Download Report
                    </button>
                </form>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<style>
    .report-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem;
    }

    .page-header {
        text-align: center;
        margin-bottom: 3rem;
    }

    .page-header h2 {
        color: var(--text-color);
        margin-bottom: 0.5rem;
    }

    .page-header p {
        color: #666;
    }

    .students-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 2rem;
    }

    .student-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        padding: 1.5rem;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .student-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }

    .student-info h3 {
        color: var(--text-color);
        margin-bottom: 0.5rem;
        font-size: 1.2rem;
    }

    .roll-number {
        color: var(--primary-color);
        font-weight: 500;
        margin-bottom: 0.25rem;
    }

    .department {
        color: #666;
        margin-bottom: 1rem;
    }

    .stats {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
        margin-bottom: 1.5rem;
        padding: 1rem;
        background: var(--light-bg);
        border-radius: 5px;
    }

    .stat {
        text-align: center;
    }

    .stat .label {
        display: block;
        color: #666;
        font-size: 0.9rem;
        margin-bottom: 0.25rem;
    }

    .stat .value {
        display: block;
        color: var(--text-color);
        font-weight: 600;
        font-size: 1.2rem;
    }

    .report-action {
        text-align: center;
    }

    @media (max-width: 768px) {
        .report-container {
            padding: 1rem;
        }

        .students-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php
require_once 'includes/footer.php';
$conn->close();
?> 