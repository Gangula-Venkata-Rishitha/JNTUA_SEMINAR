<?php
require_once 'includes/header.php';
require_once '../config/database.php';

$conn = getDBConnection();

// Get total number of students in the same department
$stmt = $conn->prepare("SELECT COUNT(*) as total_students FROM users WHERE role = 'student' AND department = ?");
$stmt->bind_param("s", $user['department']);
$stmt->execute();
$total_students = $stmt->get_result()->fetch_assoc()['total_students'];

// Get total number of seminars from students in the same department
$stmt = $conn->prepare("
    SELECT COUNT(*) as total_seminars 
    FROM seminars s
    JOIN users u ON s.student_id = u.user_id 
    WHERE u.department = ? AND u.role = 'student'
");
$stmt->bind_param("s", $user['department']);
$stmt->execute();
$total_seminars = $stmt->get_result()->fetch_assoc()['total_seminars'];

// Get pending evaluations for seminars in the same department
$stmt = $conn->prepare("
    SELECT COUNT(*) as pending_evaluations 
    FROM seminars s
    JOIN users u ON s.student_id = u.user_id 
    WHERE s.evaluation_status = 'pending' 
    AND u.department = ? 
    AND u.role = 'student'
");
$stmt->bind_param("s", $user['department']);
$stmt->execute();
$pending_evaluations = $stmt->get_result()->fetch_assoc()['pending_evaluations'];

// Get recent seminars from students in the same department
$stmt = $conn->prepare("
    SELECT 
        s.seminar_id,
        s.title,
        s.created_at,
        s.evaluation_status,
        u.full_name as student_name 
    FROM seminars s 
    JOIN users u ON s.student_id = u.user_id 
    WHERE u.department = ? 
    AND u.role = 'student'
    ORDER BY s.created_at DESC 
    LIMIT 5
");
$stmt->bind_param("s", $user['department']);
$stmt->execute();
$recent_seminars = $stmt->get_result();
?>

<div class="dashboard-container">
    <!-- Welcome Section -->
    <div class="welcome-section">
        <h1>Welcome, <?php echo htmlspecialchars($user['full_name']); ?>!</h1>
        <p>Here's an overview of your academic activities in the <?php echo htmlspecialchars($user['department']); ?> department</p>
    </div>

    <!-- Statistics Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <i class="fas fa-user-graduate"></i>
            <div class="stat-info">
                <h3>Total Students</h3>
                <p><?php echo $total_students; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <i class="fas fa-chalkboard"></i>
            <div class="stat-info">
                <h3>Total Seminars</h3>
                <p><?php echo $total_seminars; ?></p>
            </div>
        </div>
        <div class="stat-card">
            <i class="fas fa-clock"></i>
            <div class="stat-info">
                <h3>Pending Evaluations</h3>
                <p><?php echo $pending_evaluations; ?></p>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
        <h2>Quick Actions</h2>
        <div class="action-buttons">
            <a href="evaluate_seminars.php" class="btn-primary">
                <i class="fas fa-chalkboard-teacher"></i>
                Evaluate Seminars
            </a>
            <a href="reports.php" class="btn-secondary">
                <i class="fas fa-file-pdf"></i>
                Generate Reports
            </a>
        </div>
    </div>

    <!-- Recent Seminars -->
    <div class="recent-seminars">
        <div class="section-header">
            <h2>Recent Seminars</h2>
            <a href="evaluate_seminars.php" class="view-all">View All</a>
        </div>
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Title</th>
                        <th>Upload Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($seminar = $recent_seminars->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($seminar['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($seminar['title']); ?></td>
                            <td><?php echo date('M d, Y', strtotime($seminar['created_at'])); ?></td>
                            <td>
                                <span class="status-badge <?php echo strtolower($seminar['evaluation_status']); ?>">
                                    <?php echo ucfirst($seminar['evaluation_status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="evaluate_seminar.php?id=<?php echo $seminar['seminar_id']; ?>" 
                                   class="btn-icon" title="Evaluate">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
    .dashboard-container {
        max-width: 1200px;
        margin: 0 auto;
    }

    .welcome-section {
        margin-bottom: 2rem;
    }

    .welcome-section h1 {
        color: var(--text-color);
        margin-bottom: 0.5rem;
    }

    .welcome-section p {
        color: #666;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .stat-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .stat-card i {
        font-size: 2rem;
        color: var(--primary-color);
    }

    .stat-info h3 {
        font-size: 0.9rem;
        color: #666;
        margin-bottom: 0.5rem;
    }

    .stat-info p {
        font-size: 1.5rem;
        font-weight: 600;
        color: var(--text-color);
    }

    .quick-actions {
        margin-bottom: 2rem;
    }

    .quick-actions h2 {
        margin-bottom: 1rem;
        color: var(--text-color);
    }

    .action-buttons {
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
    }

    .recent-seminars {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }

    .view-all {
        color: var(--primary-color);
        text-decoration: none;
        font-size: 0.9rem;
    }

    .status-badge {
        padding: 0.25rem 0.5rem;
        border-radius: 15px;
        font-size: 0.85rem;
        font-weight: 500;
    }

    .status-badge.pending {
        background: #fff3cd;
        color: #856404;
    }

    .status-badge.evaluated {
        background: #d4edda;
        color: #155724;
    }

    @media (max-width: 768px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }

        .action-buttons {
            flex-direction: column;
        }

        .action-buttons a {
            width: 100%;
        }
    }
</style>

<?php
$stmt->close();
$conn->close();
require_once 'includes/footer.php';
?> 