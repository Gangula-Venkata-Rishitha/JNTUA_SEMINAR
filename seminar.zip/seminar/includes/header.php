<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Get user data
$user = getDBConnection()->query("SELECT * FROM users WHERE user_id = " . $_SESSION['user_id'])->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SeminarHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="../includes/styles/main.css">
</head>
<body>
    <nav class="main-nav">
        <div class="nav-brand">
            <a href="dashboard.php" class="brand-link">
                <i class="fas fa-graduation-cap"></i>
                <span>SeminarHub</span>
            </a>
        </div>
        
        <div class="nav-links">
            <?php if ($user['role'] === 'hod'): ?>
                <a href="dashboard.php" class="nav-link"><i class="fas fa-home"></i> Dashboard</a>
                <a href="view_faculty.php" class="nav-link"><i class="fas fa-chalkboard-teacher"></i> Faculty</a>
                <a href="view_students.php" class="nav-link"><i class="fas fa-user-graduate"></i> Students</a>
                <a href="generate_report.php" class="nav-link"><i class="fas fa-file-pdf"></i> Reports</a>
            <?php elseif ($user['role'] === 'faculty'): ?>
                <a href="dashboard.php" class="nav-link"><i class="fas fa-home"></i> Dashboard</a>
                <a href="evaluate_seminars.php" class="nav-link"><i class="fas fa-tasks"></i> Evaluate</a>
                <a href="generate_report.php" class="nav-link"><i class="fas fa-file-pdf"></i> Reports</a>
            <?php else: ?>
                <a href="dashboard.php" class="nav-link"><i class="fas fa-home"></i> Dashboard</a>
                <a href="upload_seminar.php" class="nav-link"><i class="fas fa-upload"></i> Upload</a>
                <a href="my_seminars.php" class="nav-link"><i class="fas fa-video"></i> My Seminars</a>
            <?php endif; ?>
        </div>
        
        <div class="nav-profile">
            <div class="profile-info">
                <span class="user-name"><?php echo htmlspecialchars($user['full_name']); ?></span>
                <span class="user-role"><?php echo ucfirst($user['role']); ?></span>
            </div>
            <a href="../logout.php" class="btn-logout">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </nav>

    <nav class="mobile-nav">
        <div class="mobile-nav-items">
            <?php if ($user['role'] === 'hod'): ?>
                <a href="dashboard.php" class="mobile-nav-item">
                    <i class="fas fa-home"></i>
                    <span>Home</span>
                </a>
                <a href="view_faculty.php" class="mobile-nav-item">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span>Faculty</span>
                </a>
                <a href="view_students.php" class="mobile-nav-item">
                    <i class="fas fa-user-graduate"></i>
                    <span>Students</span>
                </a>
                <a href="generate_report.php" class="mobile-nav-item">
                    <i class="fas fa-file-pdf"></i>
                    <span>Reports</span>
                </a>
            <?php elseif ($user['role'] === 'faculty'): ?>
                <a href="dashboard.php" class="mobile-nav-item">
                    <i class="fas fa-home"></i>
                    <span>Home</span>
                </a>
                <a href="evaluate_seminars.php" class="mobile-nav-item">
                    <i class="fas fa-tasks"></i>
                    <span>Evaluate</span>
                </a>
                <a href="generate_report.php" class="mobile-nav-item">
                    <i class="fas fa-file-pdf"></i>
                    <span>Reports</span>
                </a>
            <?php else: ?>
                <a href="dashboard.php" class="mobile-nav-item">
                    <i class="fas fa-home"></i>
                    <span>Home</span>
                </a>
                <a href="upload_seminar.php" class="mobile-nav-item">
                    <i class="fas fa-upload"></i>
                    <span>Upload</span>
                </a>
                <a href="my_seminars.php" class="mobile-nav-item">
                    <i class="fas fa-video"></i>
                    <span>Seminars</span>
                </a>
            <?php endif; ?>
        </div>
    </nav>

    <style>
        .main-nav {
            background: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .nav-brand {
            display: flex;
            align-items: center;
        }

        .brand-link {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--primary-color);
            text-decoration: none;
            font-size: 1.5rem;
            font-weight: 600;
        }

        .nav-links {
            display: flex;
            gap: 2rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-color);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
        }

        .nav-link:hover {
            color: var(--primary-color);
        }

        .nav-profile {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .profile-info {
            text-align: right;
        }

        .user-name {
            display: block;
            font-weight: 500;
            color: var(--text-color);
        }

        .user-role {
            display: block;
            font-size: 0.8rem;
            color: #666;
        }

        .btn-logout {
            color: var(--text-color);
            text-decoration: none;
            padding: 0.5rem;
            border-radius: 50%;
            transition: var(--transition);
        }

        .btn-logout:hover {
            background: var(--light-bg);
            color: var(--primary-color);
        }

        @media (max-width: 768px) {
            .main-nav {
                padding: 1rem;
            }

            .nav-links {
                display: none;
            }

            .profile-info {
                display: none;
            }

            .brand-link span {
                display: none;
            }
        }
    </style>

    <div class="container">
        <!-- Content will be injected here -->
    </div>
</body>
</html> 