<?php
function checkAuth($required_role = null) {
    session_start();
    
    if (!isset($_SESSION['user_id'])) {
        header("Location: /login.php");
        exit();
    }
    
    if ($required_role !== null && $_SESSION['role'] !== $required_role) {
        header("Location: /login.php");
        exit();
    }
    
    return [
        'user_id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'role' => $_SESSION['role'],
        'full_name' => $_SESSION['full_name'],
        'department' => $_SESSION['department'] ?? null
    ];
}
?> 