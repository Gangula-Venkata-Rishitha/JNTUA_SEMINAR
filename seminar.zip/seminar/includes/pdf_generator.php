<?php
require_once '../vendor/tecnickcom/tcpdf/tcpdf.php';

class SeminarReportPDF extends TCPDF {
    // Header
    public function Header() {
        $this->SetFont('helvetica', 'B', 16);
        $this->Cell(0, 15, 'SeminarHub - Report', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        $this->Ln(20);
    }

    // Footer
    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('helvetica', 'I', 8);
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }

    // Section Title
    public function SectionTitle($title) {
        $this->SetFont('helvetica', 'B', 14);
        $this->Cell(0, 10, $title, 0, 1, 'L');
        $this->Ln(5);
    }

    // Table Header
    public function TableHeader($headers) {
        $this->SetFont('helvetica', 'B', 11);
        $this->SetFillColor(52, 144, 226);
        $this->SetTextColor(255);
        
        $width = 190 / count($headers);
        foreach ($headers as $header) {
            $this->Cell($width, 10, $header, 1, 0, 'C', 1);
        }
        $this->Ln();
        $this->SetTextColor(0);
    }

    // Table Row
    public function TableRow($data) {
        $this->SetFont('helvetica', '', 10);
        $width = 190 / count($data);
        foreach ($data as $value) {
            $this->Cell($width, 10, $value, 1, 0, 'C');
        }
        $this->Ln();
    }

    // Info Section
    public function InfoSection($title, $data) {
        $this->SetFont('helvetica', 'B', 12);
        $this->Cell(0, 10, $title, 0, 1, 'L');
        
        $this->SetFont('helvetica', '', 11);
        foreach ($data as $key => $value) {
            $this->Cell(50, 8, $key . ':', 0, 0);
            $this->Cell(0, 8, $value, 0, 1);
        }
        $this->Ln(5);
    }

    // Evaluation Details
    public function EvaluationDetails($evaluation) {
        $this->SetFont('helvetica', 'B', 12);
        $this->Cell(0, 10, 'Evaluation Details', 0, 1, 'L');
        
        $this->SetFont('helvetica', '', 11);
        $this->Cell(50, 8, 'Score:', 0, 0);
        $this->Cell(0, 8, $evaluation['score'] . '/10', 0, 1);
        
        $this->Cell(50, 8, 'Evaluated By:', 0, 0);
        $this->Cell(0, 8, $evaluation['faculty_name'], 0, 1);
        
        $this->Cell(50, 8, 'Evaluation Date:', 0, 0);
        $this->Cell(0, 8, date('F j, Y', strtotime($evaluation['evaluation_date'])), 0, 1);
        
        $this->Ln(5);
        $this->Cell(0, 8, 'Remarks:', 0, 1);
        $this->MultiCell(0, 8, $evaluation['remarks'], 0, 'L');
        $this->Ln(5);
    }

    // Statistics Section
    public function StatisticsSection($stats) {
        $this->SectionTitle('Statistics');
        
        $this->SetFont('helvetica', '', 11);
        foreach ($stats as $key => $value) {
            $this->Cell(100, 8, $key . ':', 0, 0);
            $this->Cell(0, 8, $value, 0, 1);
        }
        $this->Ln(5);
    }
}
?> 